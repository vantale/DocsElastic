using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PnP.Core.Auth.Services.Builder.Configuration;
using PnP.Core.Services;
using PnP.Core.Model.SharePoint;
using PnP.Core.Model.Security;
using PnP.Core.QueryModel;
using PnP.Core.Model;

public class Manifest
{
    [JsonPropertyName("pages")] public List<PageEntry> Pages { get; set; } = new();
}
public class PageEntry
{
    [JsonPropertyName("id")] public string Id { get; set; } = "";
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("slug")] public string Slug { get; set; } = "";
    [JsonPropertyName("htmlPath")] public string HtmlPath { get; set; } = "";
    [JsonPropertyName("labels")] public List<string> Labels { get; set; } = new();
    [JsonPropertyName("attachments")] public List<string> Attachments { get; set; } = new();
    [JsonPropertyName("originalLinks")] public List<string> OriginalLinks { get; set; } = new();
}

public record AppConfig(
    string SiteUrl,
    string ManifestPath,
    string AttachmentsLibraryTitle,
    string AttachmentsFolder,
    bool UseEnterpriseKeywords,
    string EnterpriseKeywordsFieldInternalName
);

class Program
{
    static async Task<int> Main(string[] args)
    {
        var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false);

        var config = builder.Build();

        // Bind app config
        var appCfg = config.GetSection("App").Get<AppConfig>() ??
            throw new InvalidOperationException("Missing App section in appsettings.json");

        // Setup DI with PnP Core + Auth (Interactive auth by default)
        var services = new ServiceCollection();
        services.AddPnPCore(options =>
        {
            options.PnPContext.GraphFirst = true;
        });
        services.AddPnPCoreAuthentication(options =>
        {
            // "Default" auth configuration must exist in appsettings.json under PnPCore:Credentials:Configurations
            options.Credentials.Configurations.Add("Default",
                new CredentialConfiguration
                {
                    ClientId = config["PnPCore:Credentials:Default:ClientId"],
                    TenantId = config["PnPCore:Credentials:Default:TenantId"],
                    Interactive = new InteractiveAuthenticationOptions
                    {
                        RedirectUri = new Uri(config["PnPCore:Credentials:Default:RedirectUri"]!)
                    }
                });
        });
        var sp = services.BuildServiceProvider();
        var factory = sp.GetRequiredService<IPnPContextFactory>();

        // Load manifest
        var manifestJson = await File.ReadAllTextAsync(appCfg.ManifestPath);
        var manifest = JsonSerializer.Deserialize<Manifest>(manifestJson) ?? new Manifest();

        Console.WriteLine($"Loaded manifest with {manifest.Pages.Count} pages");

        // Pass 1: Create empty pages (build ConfluenceId -> SPO page URL map)
        var pageUrlById = new Dictionary<string, string>(); // absolute URL
        using (var context = await factory.CreateAsync(new Uri(appCfg.SiteUrl), "Default"))
        {
            // Ensure Site Pages list exists
            var sitePages = await context.Web.Lists.GetByTitleAsync("Site Pages", l => l.RootFolder);
            foreach (var p in manifest.Pages)
            {
                var name = $"{p.Slug}.aspx";
                IPage? page = null;
                try
                {
                    page = await context.Web.Pages.GetByNameAsync(name);
                }
                catch
                {
                    // ignore
                }

                if (page == null)
                {
                    Console.WriteLine($"[CREATE] {name}");
                    page = await context.Web.NewPageAsync(PageLayoutType.Article);
                    page.PageTitle = string.IsNullOrWhiteSpace(p.Title) ? p.Slug : p.Title;
                    page.Sections.Clear();
                    page.Sections.Add(new CanvasSection(page, CanvasSectionTemplate.OneColumn));
                    page.Sections[0].Controls.Add(new PageText { Text = "<p>Placeholder</p>" });
                    await page.SaveAsync(name);
                    await page.PublishAsync();
                }
                else
                {
                    Console.WriteLine($"[EXISTS] {name}");
                }

                // Resolve absolute URL
                var file = await context.Web.GetFileByServerRelativeUrlAsync(page!.ServerRelativeUrl);
                var abs = $"{new Uri(appCfg.SiteUrl).GetLeftPart(UriPartial.Authority)}{file.ServerRelativeUrl}";
                pageUrlById[p.Id] = abs;
            }
        }

        // Pass 2: Upload attachments and build old->new URL map
        var oldToNewAttachmentUrl = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        using (var context = await factory.CreateAsync(new Uri(appCfg.SiteUrl), "Default"))
        {
            var docs = await context.Web.Lists.GetByTitleAsync(appCfg.AttachmentsLibraryTitle, l => l.RootFolder);
            foreach (var p in manifest.Pages)
            {
                var html = await File.ReadAllTextAsync(p.HtmlPath);
                var matches = Regex.Matches(html, @"['""](\/download\/attachments\/[^'"" \t\r\n]+)['""]");
                if (matches.Count == 0) continue;

                // Ensure attachments subfolder
                var subFolderPath = $"{docs.RootFolder.ServerRelativeUrl.TrimEnd('/')}/{appCfg.AttachmentsFolder}/{p.Slug}";
                var subFolder = await EnsureFolderAsync(context, subFolderPath);

                foreach (Match m in matches)
                {
                    var oldUrl = m.Groups[1].Value;
                    var fileName = Uri.UnescapeDataString(new Uri("http://dummy" + oldUrl).Segments.Last());
                    var candidate = FindAttachmentNear(p.HtmlPath, fileName);
                    if (candidate == null)
                    {
                        Console.WriteLine($"[WARN] Missing local attachment for {fileName} (ref by {p.Title})");
                        continue;
                    }

                    // Upload (overwrite=true to be idempotent)
                    await using var fs = File.OpenRead(candidate);
                    await subFolder.Files.AddAsync(fileName, fs, true);
                    var newServerRel = $"{subFolder.ServerRelativeUrl}/{fileName}";
                    var newAbs = $"{new Uri(appCfg.SiteUrl).GetLeftPart(UriPartial.Authority)}{newServerRel}";
                    oldToNewAttachmentUrl[oldUrl] = newAbs;
                    Console.WriteLine($"[UPLOADED] {fileName} → {newAbs}");
                }
            }
        }

        // Pass 3: Write final HTML (rewrite links), set labels, publish
        using (var context = await factory.CreateAsync(new Uri(appCfg.SiteUrl), "Default"))
        {
            var sitePages = await context.Web.Lists.GetByTitleAsync("Site Pages", l => l.RootFolder);
            foreach (var p in manifest.Pages)
            {
                var name = $"{p.Slug}.aspx";
                var page = await context.Web.Pages.GetByNameAsync(name) ?? throw new Exception($"Page not found after creation: {name}");
                var html = await File.ReadAllTextAsync(p.HtmlPath);

                // Rewrite Confluence pageId links -> SharePoint modern page absolute URLs
                html = Regex.Replace(html, "href=\"[^\"]*pageId=(\\d+)[^\"]*\"", m =>
                {
                    var id = m.Groups[1].Value;
                    return pageUrlById.TryGetValue(id, out var targetAbs)
                        ? $"href=\"{targetAbs}\""
                        : m.Value;
                }, RegexOptions.IgnoreCase);

                // Rewrite attachments
                foreach (var kv in oldToNewAttachmentUrl)
                {
                    var pattern = $"(href|src)=\"{Regex.Escape(kv.Key)}\"";
                    html = Regex.Replace(html, pattern, $"$1=\"{kv.Value}\"", RegexOptions.IgnoreCase);
                }

                // Replace the single text control content
                page.Sections.Clear();
                page.Sections.Add(new CanvasSection(page, CanvasSectionTemplate.OneColumn));
                page.Sections[0].Controls.Add(new PageText { Text = html });
                await page.SaveAsync(name);
                await page.PublishAsync();
                Console.WriteLine($"[UPDATED] {name} content");

                // Labels → Enterprise Keywords or custom column
                if (p.Labels.Count > 0)
                {
                    var file = await context.Web.GetFileByServerRelativeUrlAsync(page.ServerRelativeUrl, f => f.ListItemAllFields);
                    if (appCfg.UseEnterpriseKeywords)
                    {
                        var fieldName = string.IsNullOrWhiteSpace(appCfg.EnterpriseKeywordsFieldInternalName) ? "TaxKeyword" : appCfg.EnterpriseKeywordsFieldInternalName;
                        file.ListItemAllFields.Values[fieldName] = string.Join(";", p.Labels);
                    }
                    else
                    {
                        // fallback to a custom text column named 'ConfLabels'
                        file.ListItemAllFields.Values["ConfLabels"] = string.Join(";", p.Labels);
                    }
                    await file.ListItemAllFields.UpdateAsync();
                    Console.WriteLine($"[LABELS] {name} <- {string.Join(", ", p.Labels)}");
                }
            }
        }

        Console.WriteLine("DONE.");
        return 0;
    }

    // Ensures a folder by server-relative URL (creates intermediate folders as needed)
    private static async Task<IFolder> EnsureFolderAsync(PnPContext context, string serverRelativeUrl)
    {
        // Try get
        try
        {
            var existing = await context.Web.GetFolderByServerRelativeUrlAsync(serverRelativeUrl);
            if (existing != null) return existing;
        }
        catch { /* ignore */ }

        // Create chain
        var parts = serverRelativeUrl.Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries);
        var pathSoFar = "";
        IFolder? current = null;

        foreach (var part in parts)
        {
            pathSoFar += "/" + part;
            try
            {
                current = await context.Web.GetFolderByServerRelativeUrlAsync(pathSoFar);
            }
            catch
            {
                // Create under parent
                var parentPath = "/" + string.Join("/", pathSoFar.Trim('/').Split('/')[..^1]);
                var parent = await context.Web.GetFolderByServerRelativeUrlAsync(parentPath);
                current = await parent.Folders.AddAsync(part);
            }
        }
        return current!;
    }

    // Finds an attachment file near the HTML file (searches sibling 'attachments' folders up the tree)
    private static string? FindAttachmentNear(string htmlPath, string fileName)
    {
        var start = new DirectoryInfo(Path.GetDirectoryName(htmlPath)!);
        var maxUp = 5;
        for (int i = 0; i < maxUp && start != null; i++, start = start.Parent!)
        {
            var attachDir = Path.Combine(start.FullName, "attachments");
            if (Directory.Exists(attachDir))
            {
                var candidate = Directory.EnumerateFiles(attachDir, fileName, SearchOption.AllDirectories).FirstOrDefault();
                if (candidate != null) return candidate;
            }
        }
        return null;
    }
}
