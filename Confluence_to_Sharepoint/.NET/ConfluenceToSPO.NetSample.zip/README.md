# Confluence → SharePoint Online (Pure .NET with PnP Core SDK)

This sample replaces PowerShell with a **.NET 8 console** using **PnP Core SDK** to:
- Create modern pages
- Insert your **cleaned HTML** (from the Python transformer)
- Upload attachments and **rewrite links**
- Set **labels** (Enterprise Keywords or custom column)
- Publish pages

> It expects the `manifest.json` produced by your transformer (format from the earlier runbook).

## 1) Prereqs

- .NET 8 SDK
- An Entra App Registration (Public client) with delegated permissions for SharePoint/Graph. Put its **ClientId** and **TenantId** into `appsettings.json`. Interactive auth will prompt you (redirect URI `http://localhost`).

Packages are already referenced in the `.csproj`:
- `PnP.Core`, `PnP.Core.Auth`
- `Microsoft.Extensions.Configuration.Json`

## 2) Configure

Edit `src/appsettings.json`:
```json
{
  "App": {
    "SiteUrl": "https://YOURTENANT.sharepoint.com/sites/YourSite",
    "ManifestPath": "../out/manifest.json",
    "AttachmentsLibraryTitle": "Documents",
    "AttachmentsFolder": "ConfluenceAttachments",
    "UseEnterpriseKeywords": true,
    "EnterpriseKeywordsFieldInternalName": "TaxKeyword"
  },
  "PnPCore": {
    "Credentials": {
      "Default": {
        "ClientId": "YOUR-APP-CLIENT-ID",
        "TenantId": "YOUR-TENANT-ID-GUID",
        "RedirectUri": "http://localhost"
      }
    }
  }
}
```

> Ensure **Enterprise Keywords** is enabled on **Site Pages** if you keep `UseEnterpriseKeywords: true`. Otherwise set it to `false` and the code will use a `ConfLabels` text column.

## 3) Build & Run

```bash
cd src
dotnet restore
dotnet run
```

The app:
1. **Creates empty pages** (to get their URLs).
2. Uploads **attachments** referenced in HTML (looks for a sibling `attachments/` folder near your HTML or up to 5 levels up).
3. Rewrites:
   - `href="...pageId=12345..."` → new **modern page URLs**
   - `/download/attachments/.../file.ext` → uploaded **SPO URLs**
4. Injects the final HTML into a single **Text** web part and **publishes**.
5. Sets labels (Enterprise Keywords or `ConfLabels`).

## 4) Notes

- For richer layouts, replace the single Text control with multiple sections/controls (`page.Sections.Add(...);`).
- If your Confluence export uses **pretty display links** instead of `pageId`, add a pass that maps titles/ancestors to IDs during transform and put placeholders the C# can replace.
- If your tenant enforces **MFA**, interactive auth will show a device code / browser prompt automatically.
