# Edge UI‑Assisted SharePoint Cookie Smoke Test (C#/.NET 8)

**Scenario covered:**
1. App starts (or connects to) system **Edge** with **remote debugging** — no extra browser install.
2. You open the SharePoint site (app can also navigate there).
3. App captures **FedAuth** & **rtFa** cookies via **CDP**.
4. App calls `/_api/web/title` using those cookies to prove API access.

## Build & Run
```powershell
dotnet build .\EdgeCookieSmokeTest.sln
dotnet run --project .\EdgeCookieSmokeTest\EdgeCookieSmokeTest.csproj -- --site=https://yourtenant.sharepoint.com/sites/YourSite
```
- If Edge is not already running with DevTools, the app will launch it.
- Complete your M365 login; the console will detect cookies and call the API.

## Configuration (`appsettings.json`)
```json
{
  "TargetSiteUrl": "https://yourtenant.sharepoint.com/sites/YourSite",
  "ApiCheckPath": "/_api/web/title",
  "RemoteDebuggingPort": 9222,
  "WaitTimeoutSeconds": 300,
  "CookiesOutputPath": "cookies.json",
  "EdgeExecutable": null,
  "ProfileDirectory": "Default"
}
```
You can override from CLI: `--site=... --port=... --profile=... --edge="C:\\Path\\to\\msedge.exe"`

## Notes
- **No Playwright browser download**: we only use CDP attach to your system Edge.
- If Edge is already running without the debug flag, close it first so the app can relaunch with `--remote-debugging-port`.
- Keep `cookies.json` safe; delete after the smoke test.
