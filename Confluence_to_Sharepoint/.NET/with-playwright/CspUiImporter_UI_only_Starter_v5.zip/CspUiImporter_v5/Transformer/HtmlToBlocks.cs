using HtmlAgilityPack;

namespace CspUiImporter.Transformer;

public static class HtmlToBlocks
{
    public static List<Block> Convert(string html, string assetsRoot)
    {
        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var body = doc.DocumentNode.SelectSingleNode("//body") ?? doc.DocumentNode;
        var outBlocks = new List<Block>();

        foreach (var node in body.ChildNodes)
        {
            Append(outBlocks, node, assetsRoot);
        }
        return outBlocks;
    }

    private static void Append(List<Block> outBlocks, HtmlNode node, string assetsRoot)
    {
        if (node.NodeType == HtmlNodeType.Comment) return;
        if (string.IsNullOrWhiteSpace(node.InnerText) && node.Name is not ("img" or "table")) return;

        switch (node.Name.ToLowerInvariant())
        {
            case "h1": case "h2": case "h3":
                int lvl = node.Name[1] - '0';
                outBlocks.Add(new Heading(lvl, HtmlAgilityPack.HtmlEntity.DeEntitize(node.InnerText.Trim())));
                break;
            case "p":
                outBlocks.Add(new Paragraph(node.InnerHtml.Trim()));
                break;
            case "ul": case "ol":
                outBlocks.Add(new ListBlock(node.Name=="ol", node.Elements("li").Select(li => li.InnerText.Trim()).ToList()));
                break;
            case "pre":
                var code = node.InnerText;
                outBlocks.Add(new CodeBlock(LanguageFromClass(node.GetAttributeValue("class", "")), code));
                break;
            case "code":
                outBlocks.Add(new CodeBlock(LanguageFromClass(node.GetAttributeValue("class", "")), node.InnerText));
                break;
            case "img":
                var src = node.GetAttributeValue("src", "");
                var alt = node.GetAttributeValue("alt", null);
                var local = Path.Combine(assetsRoot, src.Replace('/', Path.DirectorySeparatorChar));
                outBlocks.Add(new ImageBlock(local, alt));
                break;
            case "table":
                outBlocks.Add(ParseTable(node));
                break;
            default:
                if (node.NodeType == HtmlNodeType.Text) return;
                foreach (var child in node.ChildNodes) Append(outBlocks, child, assetsRoot);
                break;
        }
    }

    private static string LanguageFromClass(string cls)
    {
        if (string.IsNullOrEmpty(cls)) return "";
        var parts = cls.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var hit = parts.FirstOrDefault(p => p.StartsWith("language-") || p.StartsWith("lang-"));
        return hit?.Split('-', 2).Last() ?? "";
    }

    private static TableBlock ParseTable(HtmlNode table)
    {
        var rows = new List<List<string>>();
        foreach (var tr in table.SelectNodes(".//tr") ?? Enumerable.Empty<HtmlNode>())
        {
            var cells = tr.SelectNodes(".//th|.//td")?.Select(td => td.InnerText.Trim()).ToList() ?? new List<string>();
            if (cells.Count>0) rows.Add(cells);
        }
        return new TableBlock(rows);
    }
}
