\
using System.Text.RegularExpressions;

namespace CspUiImporter;

public static class Slug
{
    public static string FromFileName(string name)
    {
        var s = name.Trim();
        s = Regex.Replace(s, @"[\\/:*?""<>|]+", " ");
        s = Regex.Replace(s, @"\s+", " ").Trim();
        if (s.Length > 180) s = s[..180];
        return s;
    }
}
