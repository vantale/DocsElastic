# CSP-UI Importer (Playwright .NET) – v5

UI-only SharePoint importer (no REST/Graph). Uses **system Edge** (`Channel=msedge`) and **does not require** Playwright browser downloads (proxy-friendly).

## Quick Start
```powershell
dotnet restore
dotnet build

# Configure appsettings.json
copy appsettings.example.json appsettings.json
# set SiteUrl and UserDataDir (or leave blank; a default profile path will be used)

# Import your HTML (absolute or relative path)
dotnet run -- "D:\Export\MyPage.html" --site https://contoso.sharepoint.com/sites/YourTeam
```

## What’s new in v5
- **Direct page create** via `/_layouts/15/CreateSitePage.aspx` (skips “New” menu).
- Fallbacks: **Site Pages → New → Page**, or **Site home → New → Page**.
- Locale-aware selectors (New/Nowy/Novo…, Page/Strona/Página…).
- Longer default timeout; cookie banner auto-dismiss.
- Optional proxy fields in `appsettings.json` (`ProxyServer`, `ProxyBypass`).

## Config
```json
{
  "SiteUrl": "https://contoso.sharepoint.com/sites/YourTeam",
  "UserDataDir": "C:/Users/you/AppData/Local/CspUiImporter/EdgeProfile",
  "Headless": false,
  "UiLanguage": "en-US",
  "DryRun": false,
  "ProxyServer": null,
  "ProxyBypass": null
}
```

## Note about Playwright install
We launch **system Edge**; **do not** run `playwright.ps1 install`. If you accidentally do and your proxy blocks it, just ignore—no install is needed for `Channel = "msedge"`.
