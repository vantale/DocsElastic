\
namespace CspUiImporter.Ui;

internal static class Selectors
{
    public static readonly string[] NewButtonCandidates = new[] {
        "role=button[name=/New|Nowy|Novo|Nueva|Nouvelle|Neu|Criar|Crea|Utwórz/i]",
        "[data-automationid='newSplitButton']",
        "button[aria-label*='New'],button[aria-label*='Nowy'],button[aria-label*='Novo']"
    };

    public static readonly string[] PageMenuItemCandidates = new[] {
        "role=menuitem[name=/Page|Strona|Página|Seite/i]",
        "role=menuitem[name=/Site page|Strona witryny|Página do site/i]",
        "div[role='menuitem']:has-text(/Page|Strona|Página|Seite/i)"
    };

    public static readonly string[] TitleBoxCandidates = new[] {
        "[data-automation-id='pageTitle']",
        "role=textbox[name=/Add title|Tytuł|Título|Titel/i]",
        "div[contenteditable='true'][aria-label*='title'],div[contenteditable='true'][aria-label*='Tytuł']"
    };

    public const string Publish = "role=button[name=/Publish|Post|Opublikuj|Publicar/i]";

    public const string AddWebPartButton = "[data-automation-id*='addWebPart'] button, button[aria-label*='Add a new web part']";
    public static string WebPartPicker(string name) => $"role=option[name=/^{name}$/i]";

    public const string RichTextBox = "div[contenteditable='true']";

    public const string ImageUploadButton = "role=button[name=/Upload|Prześlij|Carregar|Enviar/i]";
    public const string FileInput = "input[type=file]";

    public const string CodeWebPartLang = "select[aria-label*='Language']";
    public const string CodeTextArea = "textarea";
}
