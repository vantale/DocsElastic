\
using Microsoft.Playwright;
using CspUiImporter.Transformer;

namespace CspUiImporter.Ui;

public sealed class SharePointPageWriter : IAsyncDisposable
{
    private readonly ImportConfig _cfg;
    private IPlaywright? _playwright;
    private IBrowserContext? _ctx;
    private IPage? _page;

    public SharePointPageWriter(ImportConfig cfg) => _cfg = cfg;

    public async Task LaunchAsync()
    {
        _playwright = await Microsoft.Playwright.Playwright.CreateAsync();
        var opts = new BrowserTypeLaunchPersistentContextOptions
        {
            Channel = "msedge",
            Headless = _cfg.Headless,
            ViewportSize = new() { Width = 1400, Height = 900 },
            Proxy = string.IsNullOrWhiteSpace(_cfg.ProxyServer) ? null : new Proxy { Server = _cfg.ProxyServer },
            Args = string.IsNullOrWhiteSpace(_cfg.ProxyBypass) ? null : new[] { $"--proxy-bypass-list={_cfg.ProxyBypass}" }
        };
        var profile = string.IsNullOrWhiteSpace(_cfg.UserDataDir)
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CspUiImporter", "EdgeProfile")
            : _cfg.UserDataDir;
        Directory.CreateDirectory(profile);
        _ctx = await _playwright.Chromium.LaunchPersistentContextAsync(profile, opts);
        _page = await _ctx.NewPageAsync();
        _page.SetDefaultTimeout(60000);
    }

    public async Task OpenSiteAsync()
    {
        Ensure();
        await _page!.GotoAsync(_cfg.SiteUrl, new() { WaitUntil = WaitUntilState.DOMContentLoaded });
        await _page.WaitForSelectorAsync("header, #SuiteNavWrapper", new() { Timeout = 120_000 });
    }

    public async Task CreatePageAsync(string title)
    {
        Ensure();

        // 1) Try direct create page endpoint (bypasses 'New' menu)
        if (await TryOpenCreatePageDirectAsync())
        {
            await SetTitleAsync(title);
            return;
        }

        // 2) Fallback: Site Pages library → New → Page
        if (await TryOpenCreatePageViaLibraryAsync())
        {
            await SetTitleAsync(title);
            return;
        }

        // 3) Last resort: from site home → New → Page
        if (await TryOpenCreatePageViaHomeAsync())
        {
            await SetTitleAsync(title);
            return;
        }

        throw new InvalidOperationException("Could not open the modern page authoring canvas via any known path.");
    }

    public async Task InsertAsync(Block b)
    {
        Ensure();
        switch (b)
        {
            case Heading h:
                await AddTextWebPartIfNeeded();
                await InsertHeadingAsync(h);
                break;
            case Paragraph p:
                await AddTextWebPartIfNeeded();
                await InsertParagraphAsync(p);
                break;
            case ListBlock l:
                await AddTextWebPartIfNeeded();
                await InsertListAsync(l);
                break;
            case CodeBlock c:
                await InsertCodeAsync(c);
                break;
            case ImageBlock i:
                await InsertImageAsync(i);
                break;
            case TableBlock t:
                await AddTextWebPartIfNeeded();
                await InsertTableAsync(t);
                break;
        }
    }

    public async Task PublishAsync()
    {
        Ensure();
        await _page!.ClickAsync(Selectors.Publish);
        await _page.WaitForLoadStateAsync(LoadState.NetworkIdle);
    }

    private async Task AddTextWebPartIfNeeded()
    {
        var rtbCount = await _page!.Locator(Selectors.RichTextBox).CountAsync();
        if (rtbCount == 0)
        {
            await AddWebPart("Text");
        }
    }

    private async Task AddWebPart(string name)
    {
        var pluses = _page!.Locator(Selectors.AddWebPartButton);
        var count = await pluses.CountAsync();
        if (count == 0)
        {
            await _page.Keyboard.PressAsync("End");
            count = await pluses.CountAsync();
        }
        var target = pluses.Nth(Math.Max(0, count - 1));
        await target.ClickAsync();
        await _page.Locator(Selectors.WebPartPicker(name)).First.ClickAsync();
        await _page.WaitForTimeoutAsync(300);
    }

    private async Task InsertHeadingAsync(Heading h)
    {
        var html = $"<h{h.Level}>" + EscapeHtml(h.Text) + $"</h{h.Level}>";
        await ExecInsertHtmlAsync(html);
    }

    private async Task InsertParagraphAsync(Paragraph p)
    {
        await ExecInsertHtmlAsync(p.Html);
    }

    private async Task InsertListAsync(ListBlock l)
    {
        var tag = l.Ordered ? "ol" : "ul";
        var items = string.Join("", l.Items.Select(i => $"<li>{EscapeHtml(i)}</li>"));
        await ExecInsertHtmlAsync($"<{tag}>{items}</{tag}>");
    }

    private async Task InsertTableAsync(TableBlock t)
    {
        var rows = string.Join("", t.Cells.Select(r => "<tr>" + string.Join("", r.Select(c => $"<td>{EscapeHtml(c)}</td>")) + "</tr>"));
        await ExecInsertHtmlAsync($"<table>{rows}</table>");
    }

    private async Task InsertCodeAsync(CodeBlock c)
    {
        await AddWebPart("Code snippet");
        var langSel = _page!.Locator(Selectors.CodeWebPartLang);
        if (await langSel.CountAsync() > 0 && !string.IsNullOrWhiteSpace(c.Language))
        {
            await langSel.SelectOptionAsync(new[] { c.Language, c.Language.ToLowerInvariant(), c.Language.ToUpperInvariant() });
        }
        await _page.Locator(Selectors.CodeTextArea).FillAsync(c.Code);
    }

    private async Task InsertImageAsync(ImageBlock img)
    {
        await AddWebPart("Image");
        var fileInput = _page!.Locator(Selectors.FileInput);
        if (await fileInput.CountAsync() == 0)
        {
            var up = _page.Locator(Selectors.ImageUploadButton);
            if (await up.CountAsync() > 0) await up.ClickAsync();
        }
        await _page.SetInputFilesAsync(Selectors.FileInput, img.SrcPath);
        await _page.WaitForLoadStateAsync(LoadState.NetworkIdle);
    }

    private async Task<bool> TryOpenCreatePageDirectAsync()
    {
        var url = _cfg.SiteUrl.TrimEnd('/') + "/_layouts/15/CreateSitePage.aspx";
        await _page!.GotoAsync(url, new() { WaitUntil = WaitUntilState.DOMContentLoaded });
        await DismissBannersAsync();
        foreach (var s in Selectors.TitleBoxCandidates)
        {
            if (await _page.Locator(s).CountAsync() > 0) return true;
        }
        return false;
    }

    private async Task<bool> TryOpenCreatePageViaLibraryAsync()
    {
        var sitePages = _cfg.SiteUrl.TrimEnd('/') + "/SitePages/Forms/ByAuthor.aspx";
        await _page!.GotoAsync(sitePages);
        await DismissBannersAsync();
        try
        {
            await ClickAnyAsync(Selectors.NewButtonCandidates);
            await ClickAnyAsync(Selectors.PageMenuItemCandidates);
            foreach (var s in Selectors.TitleBoxCandidates)
            {
                if (await _page.Locator(s).CountAsync() > 0) return true;
            }
        }
        catch { /* fallthrough */ }
        return false;
    }

    private async Task<bool> TryOpenCreatePageViaHomeAsync()
    {
        await _page!.GotoAsync(_cfg.SiteUrl);
        await DismissBannersAsync();
        try
        {
            await ClickAnyAsync(Selectors.NewButtonCandidates);
            await ClickAnyAsync(Selectors.PageMenuItemCandidates);
            foreach (var s in Selectors.TitleBoxCandidates)
            {
                if (await _page.Locator(s).CountAsync() > 0) return true;
            }
        }
        catch { /* fallthrough */ }
        return false;
    }

    private async Task SetTitleAsync(string title)
    {
        foreach (var s in Selectors.TitleBoxCandidates)
        {
            var loc = _page!.Locator(s);
            if (await loc.CountAsync() > 0)
            {
                var el = loc.First;
                await el.ClickAsync();
                await _page.Keyboard.PressAsync("Control+A");
                await _page.Keyboard.TypeAsync(title);
                return;
            }
        }
        throw new TimeoutException("Could not locate the title box on the authoring canvas.");
    }

    private async Task ClickAnyAsync(string[] selectors, int timeoutMs = 60000)
    {
        foreach (var s in selectors)
        {
            var loc = _page!.Locator(s);
            try
            {
                if (await loc.CountAsync() > 0)
                {
                    await loc.First.ClickAsync(new() { Timeout = timeoutMs });
                    return;
                }
            }
            catch { /* try next */ }
        }
        throw new TimeoutException("Could not find any of selectors: " + string.Join(" | ", selectors));
    }

    private async Task DismissBannersAsync()
    {
        var candidates = new[] {
            "#onetrust-accept-btn-handler",
            "role=button[name=/Accept|Akceptuj|Zgadzam|I agree|Got it|Rozumiem/i]",
            "button:has-text('Accept')",
            "button:has-text('Akceptuj')",
            "button:has-text('Rozumiem')"
        };
        foreach (var s in candidates)
        {
            var loc = _page!.Locator(s);
            if (await loc.CountAsync() > 0)
            {
                try { await loc.First.ClickAsync(new() { Timeout = 2000 }); } catch {}
            }
        }
    }

    private async Task ExecInsertHtmlAsync(string html)
    {
        var rtb = _page!.Locator(Selectors.RichTextBox).First;
        await rtb.ClickAsync();
        await rtb.EvaluateAsync("(el, html) => { " +
            "el.focus();" +
            "const sel = window.getSelection();" +
            "const range = document.createRange();" +
            "range.selectNodeContents(el);" +
            "range.collapse(false);" +
            "sel.removeAllRanges();" +
            "sel.addRange(range);" +
            "document.execCommand('insertHTML', false, html);" +
        "}", html);
        await _page.WaitForTimeoutAsync(100);
    }

    private static string EscapeHtml(string s) => System.Net.WebUtility.HtmlEncode(s);

    private void Ensure()
    {
        if (_page is null) throw new InvalidOperationException("Launch/OpenSite first");
    }

    public async ValueTask DisposeAsync()
    {
        if (_ctx is not null) await _ctx.CloseAsync();
        _page = null; _ctx = null;
        _playwright?.Dispose();
    }
}
