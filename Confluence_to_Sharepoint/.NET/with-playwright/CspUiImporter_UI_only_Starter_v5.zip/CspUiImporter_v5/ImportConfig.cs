using System.Text.Json;

namespace CspUiImporter;

public sealed class ImportConfig
{
    public string SiteUrl { get; set; } = string.Empty;
    public string UserDataDir { get; set; } = string.Empty; // Edge profile for SSO
    public bool Headless { get; set; } = false;
    public string UiLanguage { get; set; } = "en-US"; // affects selectors
    public bool DryRun { get; set; } = false;
    public string? OverrideTitle { get; set; }

    // Optional proxy settings
    public string? ProxyServer { get; set; }
    public string? ProxyBypass { get; set; }

    public static ImportConfig Load(string path)
    {
        try
        {
            if (!File.Exists(path)) return new ImportConfig();
            var json = File.ReadAllText(path);
            return System.Text.Json.JsonSerializer.Deserialize<ImportConfig>(json) ?? new ImportConfig();
        }
        catch
        {
            return new ImportConfig();
        }
    }
}
