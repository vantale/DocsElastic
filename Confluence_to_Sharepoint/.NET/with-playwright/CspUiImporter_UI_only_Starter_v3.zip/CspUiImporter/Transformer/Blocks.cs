namespace CspUiImporter.Transformer;

public abstract record Block
{
    public virtual string Debug() => GetType().Name;
}

public sealed record Heading(int Level, string Text) : Block
{ public override string Debug() => $"H{Level}: {Text}"; }

public sealed record Paragraph(string Html) : Block
{ public override string Debug() => $"P: {Html[..Math.Min(40, Html.Length)]}…"; }

public sealed record ListBlock(bool Ordered, List<string> Items) : Block
{ public override string Debug() => $"List({(Ordered?"ol":"ul")}): {Items.Count}"; }

public sealed record CodeBlock(string Language, string Code) : Block
{ public override string Debug() => $"Code({Language}): {Math.Min(40, Code.Length)} chars"; }

public sealed record ImageBlock(string SrcPath, string? Alt) : Block
{ public override string Debug() => $"Img: {SrcPath}"; }

public sealed record TableBlock(List<List<string>> Cells) : Block
{ public override string Debug() => $"Table: {Cells.Count} rows"; }
