# CSP‑UI Importer (Playwright .NET)

**UI‑only** importer that takes a Confluence **HTML export** and recreates a **modern SharePoint page** by driving the SharePoint **web UI** (no REST/Graph).

## Prerequisites
- .NET SDK 9.0+
- Microsoft Edge (stable)
- (Windows recommended) PowerShell available as `pwsh`

## Quick Start
```bash
# 1) Restore .NET tool for Playwright CLI
dotnet tool restore

# 2) Install Playwright browsers (one‑time)
dotnet tool run playwright install

# 3) Restore & build
dotnet restore
dotnet build -c Debug

# 4) Configure app settings
copy appsettings.example.json appsettings.json  # Windows
# edit SiteUrl and UserDataDir in appsettings.json

# 5) Dry run (just parse blocks)
dotnet run -- samples/SamplePage.html --dryrun

# 6) Real run (opens Edge UI, signs you in if needed)
dotnet run -- samples/SamplePage.html --site https://contoso.sharepoint.com/sites/YourTeam
```

> First run may prompt you to sign into M365. The app uses a **persistent Edge profile** at `UserDataDir` so subsequent runs are SSO.

## What it does
- Opens your SharePoint site
- **New → Page**, sets title, inserts content blocks:
  - Headings/paragraphs/lists/tables into **Text** web part
  - Images via **Image** web part (uploads from local export folder)
  - Code blocks via **Code Snippet** web part
- Publishes the page

## Limitations (MVP)
- SharePoint sanitizes HTML; complex styling/macros are simplified
- You must be allowed to create/edit pages **via UI** in *Site Pages*
- Non‑English tenants may need selector tweaks (see `Ui/Selectors.cs`)

## Configuration (`appsettings.json`)
```json
{
  "SiteUrl": "https://contoso.sharepoint.com/sites/YourTeam",
  "UserDataDir": "C:/Users/you/AppData/Local/CspUiImporter/EdgeProfile",
  "Headless": false,
  "UiLanguage": "en-US",
  "DryRun": false
}
```

## Content mapping (Confluence → SharePoint Modern)
| Confluence | Handling |
|---|---|
| H1–H3 | Insert into Text web part as semantic headings |
| Paragraphs/links | Pasted HTML (sanitized by SharePoint) |
| Lists | Pasted `<ul>/<ol>` |
| Tables | Pasted `<table>`; SharePoint applies its styles |
| Code | **Code Snippet** web part (language if detected) |
| Images | **Image** web part, upload from device |
| Attachments/macros | (Next) Map to File viewer / info callouts |

## Troubleshooting
- **Publish disabled**: ensure a title is set and canvas focused
- **Login loop**: open the site once manually with the same UserDataDir
- **Image upload fails**: check local path; wait for thumbnail after upload
- **Selectors mismatch**: update regexes in `Ui/Selectors.cs`

## License
MIT
