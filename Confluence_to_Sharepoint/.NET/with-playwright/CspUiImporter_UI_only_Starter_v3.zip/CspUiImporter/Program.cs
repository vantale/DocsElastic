using System.Text.Json;
using CspUiImporter;
using CspUiImporter.Transformer;
using CspUiImporter.Ui;

namespace CspUiImporter;

public static class Program
{
    public static async Task<int> Main(string[] args)
    {
        if (args.Length < 1)
        {
            Console.WriteLine("Usage: CspUiImporter <path-to-exported-html> [--site <url>] [--title <pageTitle>] [--headless] [--dryrun]");
            return 2;
        }

        var htmlPath = Path.GetFullPath(args[0]);
        if (!File.Exists(htmlPath))
        {
            Console.Error.WriteLine($"HTML not found: {htmlPath}");
            return 3;
        }

        var cfg = ImportConfig.Load(Path.Combine(AppContext.BaseDirectory, "appsettings.json"));

        // CLI overrides
        for (int i = 1; i < args.Length; i++)
        {
            if (args[i] == "--site" && i + 1 < args.Length) cfg.SiteUrl = args[++i];
            else if (args[i] == "--title" && i + 1 < args.Length) cfg.OverrideTitle = args[++i];
            else if (args[i] == "--headless") cfg.Headless = true;
            else if (args[i] == "--dryrun") cfg.DryRun = true;
        }

        Console.WriteLine($"[Config] site={cfg.SiteUrl} headless={cfg.Headless} dryRun={cfg.DryRun}");

        // 1) Transform HTML → blocks
        var src = await File.ReadAllTextAsync(htmlPath);
        var blocks = HtmlToBlocks.Convert(src, Path.GetDirectoryName(htmlPath)!);
        Console.WriteLine($"[Transform] Blocks: {blocks.Count}");

        if (cfg.DryRun)
        {
            Console.WriteLine(JsonSerializer.Serialize(blocks.Select(b => b.Debug()), new JsonSerializerOptions{WriteIndented=true}));
            return 0;
        }

        // 2) Drive SharePoint UI
        var title = cfg.OverrideTitle ?? Slug.FromFileName(Path.GetFileNameWithoutExtension(htmlPath));
        var writer = new SharePointPageWriter(cfg);
        try
        {
            await writer.LaunchAsync();
            await writer.OpenSiteAsync();
            await writer.CreatePageAsync(title);
            foreach (var b in blocks)
            {
                await writer.InsertAsync(b);
            }
            await writer.PublishAsync();
            Console.WriteLine("[Done] Published.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("[Error] " + ex.Message);
            Console.Error.WriteLine(ex);
            return 1;
        }
        finally
        {
            await writer.DisposeAsync();
        }
    }
}
