# Changelog

## 2025-09-17
- Fix: C# escape issues causing compile errors in `ExecInsertHtmlAsync` (now uses Locator.EvaluateAsync with element handle).
- Fix: Corrected `Slug.cs` regex strings (removed invalid `r""` prefix; used verbatim strings).
- Security: Removed explicit `System.Text.Json` 8.0.4 reference to avoid NU1903; rely on .NET 9 inbox version.
