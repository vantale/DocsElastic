namespace CspUiImporter.Ui;

internal static class Selectors
{
    // Toolbar in Site Pages library
    public const string NewButton = "role=button[name='New']";
    public const string NewPageMenuItem = "role=menuitem[name='Page']";

    // Modern page authoring
    public const string AddTitle = "role=textbox[name='Add title']";
    public const string Publish = "role=button[name=/Publish|Post|Opublikuj|Publicar/i]";

    // Canvas
    public const string AddWebPartButton = "[data-automation-id*='addWebPart'] button, button[aria-label*='Add a new web part']";
    public static string WebPartPicker(string name) => $"role=option[name=/^{name}$/i]";

    // Text editor
    public const string RichTextBox = "div[contenteditable='true']";

    // Image dialog
    public const string ImageUploadButton = "role=button[name=/Upload|Prześlij|Carregar|Enviar/i]";
    public const string FileInput = "input[type=file]";

    // Code snippet
    public const string CodeWebPartLang = "select[aria-label*='Language']";
    public const string CodeTextArea = "textarea";
}
