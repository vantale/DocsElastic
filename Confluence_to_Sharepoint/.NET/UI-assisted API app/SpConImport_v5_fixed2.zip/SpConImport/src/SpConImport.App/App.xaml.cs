namespace SpConImport { public partial class App : System.Windows.Application { } }
