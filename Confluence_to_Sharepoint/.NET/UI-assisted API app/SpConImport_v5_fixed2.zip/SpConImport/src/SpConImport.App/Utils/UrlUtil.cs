using System.Linq;
namespace SpConImport.Utils
{
    public static class UrlUtil
    {
        public static string Combine(params string[] parts)
        {
            if (parts.Length == 0) return string.Empty;
            var s = string.Join("/", parts.Select(p => p.Trim('/')));
            if (!s.StartsWith("/")) s = "/" + s;
            return s;
        }
        public static string EncodePathSegment(string segment) =>
            Uri.EscapeDataString(segment).Replace("%2F","/");
    }
}
