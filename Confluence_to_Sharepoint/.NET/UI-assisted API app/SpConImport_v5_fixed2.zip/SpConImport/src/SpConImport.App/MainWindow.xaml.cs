using Microsoft.Web.WebView2.Wpf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;
using WinForms = System.Windows.Forms;
using SpConImport.Models;
using SpConImport.Parsers;
using SpConImport.Services;
using SpConImport.Utils;

namespace SpConImport
{
    public partial class MainWindow : Window
    {
        private readonly List<PageItem> _pages = new();
        private CookieContainer? _cookieContainer;
        private string? _spHost;

        public MainWindow()
        {
            InitializeComponent();
            Log("Ready. Scan pages, open your SharePoint site, log in, grab token, then Import.");
        }

        private void Log(string msg)
        {
            Dispatcher.Invoke(() =>
            {
                LogText.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
                LogText.ScrollToEnd();
            });
        }

        private void BrowseBtn_Click(object sender, RoutedEventArgs e)
        {
            using var dlg = new WinForms.FolderBrowserDialog();
            dlg.Description = "Select folder with exported Confluence HTML files";
            if (dlg.ShowDialog() == WinForms.DialogResult.OK)
            {
                HtmlFolderText.Text = dlg.SelectedPath;
                ScanHtmlFiles();
            }
        }

        private void BrowseXmlBtn_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "Confluence XML|*.xml;*space-export*.xml|All files|*.*", Multiselect = false };
            if (dlg.ShowDialog() == true) XmlPathText.Text = dlg.FileName;
        }

        private void ScanBtn_Click(object sender, RoutedEventArgs e) => ScanHtmlFiles();

        private void ScanHtmlFiles()
        {
            _pages.Clear();
            var dir = HtmlFolderText.Text?.Trim();
            if (string.IsNullOrWhiteSpace(dir) || !Directory.Exists(dir))
            {
                FilesCountText.Text = "No folder.";
                return;
            }

            var parser = new ConfluenceHtmlParser();
            var files = Directory.EnumerateFiles(dir, "*.htm*", SearchOption.AllDirectories).ToList();
            foreach (var f in files)
            {
                try { _pages.Add(parser.Parse(f, dir)); }
                catch (Exception ex) { Log($"Parse failed for {Path.GetFileName(f)}: {ex.Message}"); }
            }

            var xml = XmlPathText.Text?.Trim();
            if (!string.IsNullOrWhiteSpace(xml) && File.Exists(xml))
            {
                try { var idx = new ConfluenceXmlIndex(xml); foreach (var p in _pages) idx.Enrich(p); }
                catch (Exception ex) { Log($"XML enrich failed: {ex.Message}"); }
            }

            FilesCountText.Text = $"{_pages.Count} pages";
            Log($"Scanned: {_pages.Count} pages.");
        }

        private async void OpenSiteBtn_Click(object sender, RoutedEventArgs e)
        {
            var siteUrl = SiteUrlText.Text?.Trim();
            if (string.IsNullOrWhiteSpace(siteUrl)) { Log("Enter Site URL first."); return; }
            await Web.EnsureCoreWebView2Async();
            Web.Source = new Uri(siteUrl);
            Log($"Opening {siteUrl} … Please log in.");
        }

        private async void GrabCookieBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Web?.CoreWebView2 == null) { Log("WebView not ready."); return; }
                var siteUrl = SiteUrlText.Text?.Trim();
                if (string.IsNullOrWhiteSpace(siteUrl)) { Log("Enter Site URL first."); return; }

                var uri = new Uri(siteUrl);
                _spHost = $"{uri.Scheme}://{uri.Host}";
                var cookies = await Web.CoreWebView2.CookieManager.GetCookiesAsync(_spHost);

                var names = cookies.Select(c => c.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
                if (!names.Contains("FedAuth") || !names.Contains("rtFa"))
                {
                    Log("FedAuth/rtFa not found yet. Make sure you're on the site and fully logged in.");
                    AuthStatusText.Text = "Not Authenticated";
                    ImportBtn.IsEnabled = false;
                    return;
                }

                _cookieContainer = new CookieContainer();
                foreach (var c in cookies)
                {
                    try { _cookieContainer.Add(new Cookie(c.Name, c.Value, string.IsNullOrEmpty(c.Path) ? "/" : c.Path, uri.Host)); } catch { }
                }

                AuthStatusText.Text = "✓ Authenticated";
                ImportBtn.IsEnabled = true;
                Log("Captured cookies from WebView.");
            }
            catch (Exception ex) { Log("GrabCookie error: " + ex.Message); }
        }

        private async void ImportBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_cookieContainer == null || string.IsNullOrWhiteSpace(_spHost)) { Log("Authentication not captured. Use 'Grab Token' first."); return; }
            if (_pages.Count == 0) { Log("No pages scanned."); return; }

            var opts = new ImportOptions
            {
                SiteUrl = SiteUrlText.Text.Trim().TrimEnd('/'),
                LibraryTitleOrServerRelative = string.IsNullOrWhiteSpace(LibraryText.Text) ? "SiteAssets" : LibraryText.Text.Trim(),
                Subfolder = string.IsNullOrWhiteSpace(SubfolderText.Text) ? "ConfluenceImport" : SubfolderText.Text.Trim(),
                CreateModernPages = CreateModernChk.IsChecked == true,
                UploadAttachments = UploadAssetsChk.IsChecked == true,
                RewriteLinks = RewriteLinksChk.IsChecked == true,
                ConfluenceXmlPath = string.IsNullOrWhiteSpace(XmlPathText.Text) ? null : XmlPathText.Text.Trim(),
                SitePagesLibraryTitle = string.IsNullOrWhiteSpace(SitePagesTitleText.Text) ? "Site Pages" : SitePagesTitleText.Text.Trim()
            };

            try
            {
                var handler = new HttpClientHandler { CookieContainer = _cookieContainer, UseCookies = true, AllowAutoRedirect = true };
                using var client = SpConImport.Utils.HttpClientFactoryWithCookies.Create(handler);
                var uploader = new SharePointUploader(client, Log);
                var parser = new ConfluenceHtmlParser();

                Log("Fetching request digest…");
                var digest = await uploader.GetRequestDigestAsync(opts.SiteUrl);
                Log("Digest OK.");

                var sitePagesRel = await uploader.EnsureSitePagesServerRelativeAsync(opts.SiteUrl, opts.SitePagesLibraryTitle);
                var assetsRel = await uploader.GetServerRelativeFromLibraryTitleAsync(opts.SiteUrl, opts.LibraryTitleOrServerRelative);
                if (string.IsNullOrWhiteSpace(assetsRel)) throw new Exception($"Cannot resolve library '{opts.LibraryTitleOrServerRelative}'");
                var assetsFolderRel = await uploader.EnsureFolderAsync(opts.SiteUrl, assetsRel, opts.Subfolder, digest);

                var linkMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var p in _pages)
                {
                    var spPageUrl = $"{opts.SiteUrl}{UrlUtil.Combine(sitePagesRel, p.Slug + ".aspx")}";
                    linkMap[p.SourcePath.Replace("\\","/")] = spPageUrl;
                    linkMap[System.IO.Path.GetFileName(p.SourcePath)] = spPageUrl;
                }

                int ok=0, fail=0;
                foreach (var p in _pages)
                {
                    try
                    {
                        var assetServerRelFolder = UrlUtil.Combine(assetsFolderRel, p.Slug);
                        if (opts.UploadAttachments && (p.ImagePaths.Count > 0 || p.FileLinks.Count > 0))
                        {
                            try { await uploader.EnsureFolderAsync(opts.SiteUrl, assetsRel, $"{opts.Subfolder}/{p.Slug}", digest); } catch { }
                        }

                        var assetMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                        if (opts.UploadAttachments)
                        {
                            foreach (var img in p.ImagePaths.Distinct(StringComparer.OrdinalIgnoreCase))
                            {
                                var uploadedRel = await uploader.UploadFileAsync(opts.SiteUrl, assetServerRelFolder, Path.GetFileName(img), await File.ReadAllBytesAsync(img), digest);
                                assetMap[img.Replace("\\","/")] = uploadedRel;
                            }
                            foreach (var lf in p.FileLinks.Distinct(StringComparer.OrdinalIgnoreCase))
                            {
                                var uploadedRel = await uploader.UploadFileAsync(opts.SiteUrl, assetServerRelFolder, Path.GetFileName(lf), await File.ReadAllBytesAsync(lf), digest);
                                assetMap[lf.Replace("\\","/")] = uploadedRel;
                            }
                        }

                        var html = p.Html;
                        if (opts.RewriteLinks && linkMap.Count > 0) html = parser.RewriteInternalLinks(html, linkMap);
                        if (assetMap.Count > 0) html = parser.RewriteAssetLinks(html, assetMap);

                        var pageServerRel = await uploader.CreateClientSidePageAsync(opts.SiteUrl, sitePagesRel, p.Slug, digest);
                        await uploader.UpdatePageTitleAndContentAsync(opts.SiteUrl, pageServerRel, p.Title, html, digest);

                        if (p.Labels.Count > 0)
                        {
                            await uploader.EnsureLabelsFieldAsync(opts.SiteUrl, opts.LabelsFieldName, digest);
                            await uploader.SetLabelsAsync(opts.SiteUrl, pageServerRel, opts.LabelsFieldName, p.Labels, digest);
                        }

                        if (p.Comments.Count > 0) { await uploader.AddCommentsAsync(opts.SiteUrl, pageServerRel, p.Comments, digest); }

                        await uploader.PublishPageAsync(opts.SiteUrl, pageServerRel, digest);
                        ok++; Log($"OK: {p.Title} → /{pageServerRel.TrimStart('/')}");
                    }
                    catch (Exception ex) { fail++; Log($"FAIL: {p.Title} → {ex.Message}"); }
                }

                Log($"Done. Pages created: {ok}, Failed: {fail}");
            }
            catch (Exception ex) { Log("Import error: " + ex.Message); }
        }
    }
}
