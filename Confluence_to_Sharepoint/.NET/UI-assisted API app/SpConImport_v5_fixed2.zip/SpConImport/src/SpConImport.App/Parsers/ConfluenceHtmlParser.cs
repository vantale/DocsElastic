using HtmlAgilityPack;
using SpConImport.Models;
using SpConImport.Utils;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
namespace SpConImport.Parsers
{
    public class ConfluenceHtmlParser
    {
        public PageItem Parse(string filePath, string rootFolder)
        {
            var html = File.ReadAllText(filePath);
            var doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(html);

            var titleNode = doc.DocumentNode.SelectSingleNode("//title") ?? doc.DocumentNode.SelectSingleNode("//h1");
            var title = titleNode?.InnerText?.Trim() ?? Path.GetFileNameWithoutExtension(filePath);

            var page = new PageItem
            {
                SourcePath = filePath,
                Title = title,
                Slug = Slug.FromFilename(Path.GetFileNameWithoutExtension(filePath)),
                Html = html
            };

            foreach (var img in doc.DocumentNode.SelectNodes("//img[@src]") ?? Enumerable.Empty<HtmlAgilityPack.HtmlNode>())
            {
                var src = img.GetAttributeValue("src", "");
                if (string.IsNullOrWhiteSpace(src)) continue;
                if (!IsExternal(src))
                {
                    var local = NormalizeLocalPath(src, rootFolder, filePath);
                    if (File.Exists(local)) page.ImagePaths.Add(local);
                }
            }

            foreach (var a in doc.DocumentNode.SelectNodes("//a[@href]") ?? Enumerable.Empty<HtmlAgilityPack.HtmlNode>())
            {
                var href = a.GetAttributeValue("href", "");
                if (string.IsNullOrWhiteSpace(href)) continue;
                if (IsExternal(href)) continue;

                var local = NormalizeLocalPath(href, rootFolder, filePath);
                if (File.Exists(local))
                {
                    var ext = Path.GetExtension(local).ToLowerInvariant();
                    if (ext == ".html" || ext == ".htm")
                        page.InternalLinks.Add(local);
                    else
                        page.FileLinks.Add(local);
                }
            }

            return page;
        }

        public string RewriteInternalLinks(string html, System.Collections.Generic.Dictionary<string, string> linkMap)
        {
            var doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(html);
            foreach (var a in doc.DocumentNode.SelectNodes("//a[@href]") ?? Enumerable.Empty<HtmlAgilityPack.HtmlNode>())
            {
                var href = a.GetAttributeValue("href", "");
                if (string.IsNullOrWhiteSpace(href)) continue;
                if (linkMap.TryGetValue(href, out var newUrl))
                    a.SetAttributeValue("href", newUrl);
                else
                {
                    var file = href.Split('#')[0];
                    var key = file.Replace("\\", "/");
                    if (linkMap.TryGetValue(key, out newUrl))
                    {
                        var idx = href.IndexOf('#');
                        var anchor = idx >= 0 ? href[idx..] : "";
                        a.SetAttributeValue("href", newUrl + anchor);
                    }
                }
            }
            return doc.DocumentNode.OuterHtml;
        }

        public string RewriteAssetLinks(string html, System.Collections.Generic.Dictionary<string, string> assetMap)
        {
            var doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(html);
            foreach (var img in doc.DocumentNode.SelectNodes("//img[@src]") ?? Enumerable.Empty<HtmlAgilityPack.HtmlNode>())
            {
                var src = img.GetAttributeValue("src", "");
                if (string.IsNullOrWhiteSpace(src)) continue;
                if (assetMap.TryGetValue(src, out var newUrl))
                    img.SetAttributeValue("src", newUrl);
            }
            foreach (var a in doc.DocumentNode.SelectNodes("//a[@href]") ?? Enumerable.Empty<HtmlAgilityPack.HtmlNode>())
            {
                var href = a.GetAttributeValue("href", "");
                if (string.IsNullOrWhiteSpace(href)) continue;
                if (assetMap.TryGetValue(href, out var newUrl))
                    a.SetAttributeValue("href", newUrl);
            }
            return doc.DocumentNode.OuterHtml;
        }

        private static bool IsExternal(string url) => Regex.IsMatch(url, @"^[a-zA-Z]+:");

        private static string NormalizeLocalPath(string hrefOrSrc, string rootFolder, string currentFile)
        {
            var path = hrefOrSrc.Replace("/", Path.DirectorySeparatorChar.ToString());
            var baseDir = Path.GetDirectoryName(currentFile) ?? rootFolder;
            var combined = Path.GetFullPath(Path.Combine(baseDir, path));
            return combined;
        }
    }
}
