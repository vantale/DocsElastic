using System.Xml.Linq;
using SpConImport.Models;
using System.Linq;
using System.Collections.Generic;
namespace SpConImport.Parsers
{
    public class ConfluenceXmlIndex
    {
        private readonly Dictionary<string, (List<string> labels, List<string> comments)> _map = new(System.StringComparer.OrdinalIgnoreCase);
        public ConfluenceXmlIndex(string xmlPath)
        {
            var xdoc = XDocument.Load(xmlPath);
            foreach (var page in xdoc.Descendants("page"))
            {
                var title = (string?)page.Element("title") ?? "";
                if (string.IsNullOrWhiteSpace(title)) continue;
                var labels = page.Descendants("label")
                                 .Select(x => (string?)x.Attribute("name") ?? (string?)x.Value ?? "")
                                 .Where(s => !string.IsNullOrWhiteSpace(s))
                                 .Distinct(System.StringComparer.OrdinalIgnoreCase)
                                 .ToList();
                var comments = page.Descendants("comment")
                                   .Select(c => (string?)c.Element("content") ?? "")
                                   .Where(s => !string.IsNullOrWhiteSpace(s))
                                   .ToList();
                _map[title] = (labels, comments);
            }
        }
        public void Enrich(PageItem p)
        {
            if (_map.TryGetValue(p.Title, out var v))
            {
                p.Labels = v.labels;
                p.Comments = v.comments;
            }
        }
    }
}
