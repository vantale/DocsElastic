using System.Net.Http;
using System.Text;
using System.Text.Json;
using SpConImport.Models;
using SpConImport.Utils;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpConImport.Services
{
    public class SharePointUploader
    {
        private readonly HttpClient _client;
        private readonly Action<string> _log;

        public SharePointUploader(HttpClient client, Action<string> log)
        {
            _client = client;
            _log = log;
        }

        public async Task<string> GetRequestDigestAsync(string siteUrl)
        {
            using var req = new HttpRequestMessage(HttpMethod.Post, $"{siteUrl}/_api/contextinfo");
            req.Content = new StringContent(string.Empty);
            using var res = await _client.SendAsync(req);
            res.EnsureSuccessStatusCode();
            var json = await res.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            return doc.RootElement.GetProperty("d").GetProperty("GetContextWebInformation").GetProperty("FormDigestValue").GetString()!;
        }

        public async Task<string> GetServerRelativeFromLibraryTitleAsync(string siteUrl, string title)
        {
            var url = $"{siteUrl}/_api/web/lists/getbytitle('{Uri.EscapeDataString(title)}')/RootFolder/ServerRelativeUrl";
            using var res = await _client.GetAsync(url);
            if (!res.IsSuccessStatusCode) return string.Empty;
            var json = await res.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            return doc.RootElement.GetProperty("d").GetProperty("ServerRelativeUrl").GetString() ?? string.Empty;
        }

        public async Task<int> GetListItemIdForFileAsync(string siteUrl, string serverRelFile)
        {
            var url = $"{siteUrl}/_api/web/GetFileByServerRelativeUrl('{serverRelFile}')/ListItemAllFields/Id";
            using var res = await _client.GetAsync(url);
            res.EnsureSuccessStatusCode();
            var json = await res.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            return doc.RootElement.GetProperty("d").GetProperty("Id").GetInt32();
        }

        public async Task<string> EnsureFolderAsync(string siteUrl, string libraryServerRelative, string subfolder, string digest)
        {
            var folderRel = UrlUtil.Combine(libraryServerRelative, subfolder);
            if (!await FolderExistsAsync(siteUrl, folderRel))
                await CreateFolderAsync(siteUrl, folderRel, digest);
            return folderRel;
        }

        private async Task<bool> FolderExistsAsync(string siteUrl, string serverRelativeFolder)
        {
            var url = $"{siteUrl}/_api/web/GetFolderByServerRelativeUrl('{serverRelativeFolder}')/Exists";
            using var res = await _client.GetAsync(url);
            if (!res.IsSuccessStatusCode) return false;
            var json = await res.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            return doc.RootElement.GetProperty("d").GetProperty("Exists").GetBoolean();
        }

        private async Task CreateFolderAsync(string siteUrl, string serverRelativeFolder, string digest)
        {
            var url = $"{siteUrl}/_api/web/folders";
            var payload = new { __metadata = new { type = "SP.Folder" }, ServerRelativeUrl = serverRelativeFolder };
            using var req = new HttpRequestMessage(HttpMethod.Post, url);
            req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json;odata=verbose");
            req.Headers.TryAddWithoutValidation("X-RequestDigest", digest);
            using var res = await _client.SendAsync(req);
            if (!res.IsSuccessStatusCode)
                throw new Exception($"CreateFolder failed: {res.StatusCode} - {await res.Content.ReadAsStringAsync()}");
        }

        public async Task<string> UploadFileAsync(string siteUrl, string folderServerRelative, string filename, byte[] content, string digest)
        {
            var api = $"{siteUrl}/_api/web/GetFolderByServerRelativeUrl('{folderServerRelative}')/Files/Add(url='{Uri.EscapeDataString(filename)}',overwrite=true)";
            using var req = new HttpRequestMessage(HttpMethod.Post, api);
            req.Content = new ByteArrayContent(content);
            req.Headers.TryAddWithoutValidation("X-RequestDigest", digest);
            req.Headers.TryAddWithoutValidation("Accept", "application/json;odata=verbose");
            using var res = await _client.SendAsync(req);
            if (!res.IsSuccessStatusCode)
                throw new Exception($"Upload failed: {res.StatusCode} - {await res.Content.ReadAsStringAsync()}");

            var json = await res.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            var serverRel = doc.RootElement.GetProperty("d").GetProperty("ServerRelativeUrl").GetString() ?? "";
            return serverRel;
        }

        public async Task<string> EnsureSitePagesServerRelativeAsync(string siteUrl, string sitePagesTitle = "Site Pages")
        {
            var rel = await GetServerRelativeFromLibraryTitleAsync(siteUrl, sitePagesTitle);
            if (string.IsNullOrEmpty(rel)) throw new Exception($"Cannot resolve '{sitePagesTitle}' library.");
            return rel;
        }

        public async Task<string> CreateClientSidePageAsync(string siteUrl, string sitePagesRel, string slug, string digest)
        {
            var filename = $"{slug}.aspx";
            var targetUrl = UrlUtil.Combine(sitePagesRel, filename);
            var api = $"{siteUrl}/_api/web/GetFolderByServerRelativeUrl('{sitePagesRel}')/Files/AddTemplateFile(url='{Uri.EscapeDataString(filename)}',templateFileType=3)";
            using var req = new HttpRequestMessage(HttpMethod.Post, api);
            req.Headers.TryAddWithoutValidation("X-RequestDigest", digest);
            req.Headers.TryAddWithoutValidation("Accept", "application/json;odata=verbose");
            using var res = await _client.SendAsync(req);
            if (!res.IsSuccessStatusCode)
            {
                var body = await res.Content.ReadAsStringAsync();
                throw new Exception($"AddTemplateFile failed: {res.StatusCode} - {body}");
            }
            return targetUrl;
        }

        public async Task UpdatePageTitleAndContentAsync(string siteUrl, string serverRelFile, string title, string html, string digest)
        {
            var canvas = CanvasBuilder.SingleTextWebPart(html);
            var listItemId = await GetListItemIdForFileAsync(siteUrl, serverRelFile);
            var api = $"{siteUrl}/_api/web/lists/getbytitle('Site Pages')/items({listItemId})/ValidateUpdateListItem()";
            var payload = new
            {
                formValues = new[] {
                    new { FieldName = "Title", FieldValue = title },
                    new { FieldName = "CanvasContent1", FieldValue = canvas }
                },
                bNewDocumentUpdate = false
            };

            using var req = new HttpRequestMessage(HttpMethod.Post, api);
            req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json;odata=verbose");
            req.Headers.TryAddWithoutValidation("X-RequestDigest", digest);
            req.Headers.TryAddWithoutValidation("Accept", "application/json;odata=verbose");
            using var res = await _client.SendAsync(req);
            if (!res.IsSuccessStatusCode)
            {
                var body = await res.Content.ReadAsStringAsync();
                throw new Exception($"Update page fields failed: {res.StatusCode} - {body}");
            }
        }

        public async Task PublishPageAsync(string siteUrl, string serverRelFile, string digest, string comment = "Imported from Confluence")
        {
            var api = $"{siteUrl}/_api/web/GetFileByServerRelativeUrl('{serverRelFile}')/Publish(comment='{Uri.EscapeDataString(comment)}')";
            using var req = new HttpRequestMessage(HttpMethod.Post, api);
            req.Headers.TryAddWithoutValidation("X-RequestDigest", digest);
            using var res = await _client.SendAsync(req);
            if (!res.IsSuccessStatusCode)
            {
                var body = await res.Content.ReadAsStringAsync();
                throw new Exception($"Publish failed: {res.StatusCode} - {body}");
            }
        }

        public async Task EnsureLabelsFieldAsync(string siteUrl, string fieldName, string digest)
        {
            var get = $"{siteUrl}/_api/web/lists/getbytitle('Site Pages')/fields/getbyinternalnameortitle('{Uri.EscapeDataString(fieldName)}')";
            using (var res = await _client.GetAsync(get))
            {
                if (res.IsSuccessStatusCode) return;
            }
            var add = $"{siteUrl}/_api/web/lists/getbytitle('Site Pages')/fields/addfieldasxml";
            var fieldXml = $"<Field Type='Text' Name='{fieldName}' StaticName='{fieldName}' DisplayName='{fieldName}'/>";
            var payload = new { parameters = new { __metadata = new { type = "SP.AddFieldParameters" }, SchemaXml = fieldXml } };
            using var req = new HttpRequestMessage(HttpMethod.Post, add);
            req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json;odata=verbose");
            req.Headers.TryAddWithoutValidation("X-RequestDigest", digest);
            using var res2 = await _client.SendAsync(req);
            if (!res2.IsSuccessStatusCode)
            {
                var body = await res2.Content.ReadAsStringAsync();
                _log($"Warning: creating field '{fieldName}' failed: {res2.StatusCode} - {body}");
            }
        }

        public async Task SetLabelsAsync(string siteUrl, string serverRelFile, string fieldName, IEnumerable<string> labels, string digest)
        {
            var listItemId = await GetListItemIdForFileAsync(siteUrl, serverRelFile);
            var api = $"{siteUrl}/_api/web/lists/getbytitle('Site Pages')/items({listItemId})/ValidateUpdateListItem()";
            var value = string.Join("; ", labels.Distinct(StringComparer.OrdinalIgnoreCase));
            var payload = new
            {
                formValues = new[] { new { FieldName = fieldName, FieldValue = value } },
                bNewDocumentUpdate = false
            };
            using var req = new HttpRequestMessage(HttpMethod.Post, api);
            req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json;odata=verbose");
            req.Headers.TryAddWithoutValidation("X-RequestDigest", digest);
            using var res = await _client.SendAsync(req);
        }

        public async Task AddCommentsAsync(string siteUrl, string serverRelFile, IEnumerable<string> comments, string digest)
        {
            var listItemId = await GetListItemIdForFileAsync(siteUrl, serverRelFile);
            var api = $"{siteUrl}/_api/web/lists/getbytitle('Site Pages')/items({listItemId})/Comments";
            foreach (var c in comments)
            {
                var payload = new { text = c };
                using var req = new HttpRequestMessage(HttpMethod.Post, api);
                req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json;odata=verbose");
                req.Headers.TryAddWithoutValidation("X-RequestDigest", digest);
                using var res = await _client.SendAsync(req);
            }
        }
    }

    public static class CanvasBuilder
    {
        public static string SingleTextWebPart(string html)
        {
            // Build a strongly-typed object and serialize to JSON to avoid escaping issues.
            var webPartId = "d1d91016-032f-456d-98a4-721247c305e8"; // Text web part
            var payload = new
            {
                sections = new object[]
                {
                    new
                    {
                        layoutIndex = 1,
                        emphasis = 0,
                        controls = new object[]
                        {
                            new
                            {
                                controlType = 4,
                                id = Guid.NewGuid().ToString(),
                                position = new { zoneIndex = 1, sectionIndex = 1, controlIndex = 1, layoutIndex = 1 },
                                webPartId = webPartId,
                                webPartData = new
                                {
                                    id = webPartId,
                                    instanceId = Guid.NewGuid().ToString(),
                                    title = "Text",
                                    serverProcessedContent = new
                                    {
                                        htmlStrings = new { text = html }
                                    },
                                    dataVersion = "2.9"
                                }
                            }
                        }
                    }
                },
                pageSettingsSlice = new { }
            };

            return System.Text.Json.JsonSerializer.Serialize(payload);
        }
    }
}
