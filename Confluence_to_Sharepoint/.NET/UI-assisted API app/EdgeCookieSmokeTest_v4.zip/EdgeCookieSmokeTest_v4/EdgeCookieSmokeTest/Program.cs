using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Playwright;

namespace EdgeCookieSmokeTest;

public class AppConfig
{
    public string TargetSiteUrl { get; set; } = "";
    public string ApiCheckPath { get; set; } = "/_api/web/title";
    public int RemoteDebuggingPort { get; set; } = 9222; // set to 0 for dynamic
    public int WaitTimeoutSeconds { get; set; } = 300;
    public string CookiesOutputPath { get; set; } = "cookies.json";
    public string? EdgeExecutable { get; set; } = null;
    public string ProfileDirectory { get; set; } = "Default";
}

public static class Program
{
    public static async Task<int> Main(string[] args)
    {
        Console.WriteLine("== Edge UI-Assisted SharePoint Cookie Smoke Test v4 ==");
        var cfg = LoadConfig();

        foreach (var a in args)
        {
            if (a.StartsWith("--site=")) cfg.TargetSiteUrl = a["--site=".Length..];
            else if (a.StartsWith("--port=") && int.TryParse(a["--port=".Length..], out var p)) cfg.RemoteDebuggingPort = p;
            else if (a.StartsWith("--profile=")) cfg.ProfileDirectory = a["--profile=".Length..];
            else if (a.StartsWith("--edge=")) cfg.EdgeExecutable = a["--edge=".Length..];
        }

        if (string.IsNullOrWhiteSpace(cfg.TargetSiteUrl))
        {
            Console.WriteLine("ERROR: Set TargetSiteUrl or pass --site=...");
            return 1;
        }

        // 1) Launch Edge in an isolated user-data-dir to avoid single-instance conflicts
        string userDataDir;
        int actualPort;
        if (!TryFindRunningDevToolsEndpoint(out var cdpUrlExisting))
        {
            Console.WriteLine("No existing DevTools endpoint found. Launching a fresh Edge instance...");
            if (!StartEdgeIsolated(cfg, out userDataDir, out actualPort))
            {
                Console.WriteLine("ERROR: Could not start Edge with DevTools enabled.");
                return 2;
            }
            // If dynamic port requested (0), discover via DevToolsActivePort file
            if (cfg.RemoteDebuggingPort == 0)
            {
                var portFile = Path.Combine(userDataDir, "DevToolsActivePort");
                var ok = await WaitFor(() => File.Exists(portFile), TimeSpan.FromSeconds(10), 250);
                if (!ok)
                {
                    Console.WriteLine("ERROR: DevToolsActivePort not created. Edge may be blocked by policy.");
                    return 2;
                }
                var lines = await File.ReadAllLinesAsync(portFile);
                if (lines.Length >= 1 && int.TryParse(lines[0], out var parsed))
                {
                    actualPort = parsed;
                }
                else
                {
                    Console.WriteLine("ERROR: Could not parse DevToolsActivePort file.");
                    return 2;
                }
            }
            cdpUrlExisting = $"http://localhost:{actualPort}";
        }
        else
        {
            Console.WriteLine($"Found existing DevTools endpoint: {cdpUrlExisting}");
        }

        // 2) Verify endpoint
        if (!await IsCdpUp(cdpUrlExisting))
        {
            Console.WriteLine("ERROR: Could not reach Edge DevTools endpoint. Close ALL Edge instances and retry.");
            Console.WriteLine("Tip: Start Edge manually:  msedge.exe --remote-debugging-port=9222 --user-data-dir=%LOCALAPPDATA%\\EdgeCookieSmokeTest\\TempProfile --no-first-run --no-default-browser-check");
            return 2;
        }

        // 3) Attach via Playwright and proceed
        using var playwright = await Playwright.CreateAsync();
        await using var browser = await playwright.Chromium.ConnectOverCDPAsync(cdpUrlExisting);

        var ctx = browser.Contexts.FirstOrDefault();
        IPage? page = null;
        try
        {
            page = ctx != null && ctx.Pages.Count > 0 ? ctx.Pages.First() : await browser.NewPageAsync();
        }
        catch { Console.WriteLine("Open a tab manually to your SharePoint site."); }

        if (page != null)
        {
            try { await page.GotoAsync(cfg.TargetSiteUrl, new PageGotoOptions { WaitUntil = WaitUntilState.Load }); } catch {}
        }

        var deadline = DateTime.UtcNow.AddSeconds(cfg.WaitTimeoutSeconds);

        async Task<IReadOnlyList<Microsoft.Playwright.Cookie>> ReadCookiesAsync()
        {
            var bctx = browser.Contexts.FirstOrDefault();
            if (bctx == null) return Array.Empty<Microsoft.Playwright.Cookie>();
            try { return await bctx.CookiesAsync(new[] { cfg.TargetSiteUrl }); } catch { return Array.Empty<Microsoft.Playwright.Cookie>(); }
        }

        while (DateTime.UtcNow < deadline)
        {
            var cookies = await ReadCookiesAsync();
            var set = cookies.Select(x => x.Name ?? "").ToHashSet(StringComparer.OrdinalIgnoreCase);
            if (set.Contains("FedAuth") && set.Contains("rtFa"))
            {
                Console.WriteLine("✅ Login detected (FedAuth + rtFa).");
                await SaveCookiesAsync(cookies, cfg.CookiesOutputPath);
                Console.WriteLine($"Saved cookies → {cfg.CookiesOutputPath}");
                await CallSharePointApiAsync(cfg, cookies);
                Console.WriteLine("Smoke test complete.");
                return 0;
            }
            Console.Write("Waiting for login (FedAuth + rtFa)...\r");
            await Task.Delay(1000);
        }

        Console.WriteLine("\nTimeout waiting for cookies.");
        return 4;
    }

    static AppConfig LoadConfig()
    {
        var cfg = new AppConfig();
        try
        {
            if (File.Exists("appsettings.json"))
            {
                var json = File.ReadAllText("appsettings.json");
                var fromFile = JsonSerializer.Deserialize<AppConfig>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                if (fromFile != null) cfg = fromFile;
            }
        }
        catch {}
        return cfg;
    }

    static bool StartEdgeIsolated(AppConfig cfg, out string userDataDir, out int actualPort)
    {
        var baseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "EdgeCookieSmokeTest", "Profiles");
        Directory.CreateDirectory(baseDir);
        userDataDir = Path.Combine(baseDir, DateTime.UtcNow.ToString("yyyyMMdd_HHmmss"));
        Directory.CreateDirectory(userDataDir);

        // Allow dynamic port if requested
        actualPort = cfg.RemoteDebuggingPort;
        var portArg = actualPort == 0 ? "--remote-debugging-port=0" : $"--remote-debugging-port={actualPort}";

        var exe = string.IsNullOrWhiteSpace(cfg.EdgeExecutable) ? "msedge.exe" : cfg.EdgeExecutable;
        var args = $"{portArg} --user-data-dir=\"{userDataDir}\" --profile-directory={cfg.ProfileDirectory} --no-first-run --no-default-browser-check";

        try
        {
            var psi = new ProcessStartInfo(exe, args) { UseShellExecute = true };
            Process.Start(psi);
            Console.WriteLine($"Launched Edge: {exe} {args}");
            // If fixed port, give it a moment to bind
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERROR: Could not start Edge.");
            Console.WriteLine(ex.Message);
            return false;
        }
    }

    static bool TryFindRunningDevToolsEndpoint(out string cdpUrl)
    {
        cdpUrl = "";
        // Quick probe of common ports (9222..9230)
        for (var port = 9222; port <= 9230; port++)
        {
            try
            {
                using var http = new HttpClient();
                var t = http.GetAsync($"http://localhost:{port}/json/version").Result;
                if (t.IsSuccessStatusCode)
                {
                    cdpUrl = $"http://localhost:{port}";
                    return true;
                }
            }
            catch { /* ignore */ }
        }
        return false;
    }

    static async Task<bool> IsCdpUp(string cdpUrl)
    {
        try
        {
            using var http = new HttpClient();
            var resp = await http.GetAsync(cdpUrl + "/json/version");
            return resp.IsSuccessStatusCode;
        }
        catch { return false; }
    }

    static async Task<bool> WaitFor(Func<Task<bool>> cond, TimeSpan timeout, int pollMs = 200)
    {
        var end = DateTime.UtcNow + timeout;
        while (DateTime.UtcNow < end)
        {
            if (await cond()) return true;
            await Task.Delay(pollMs);
        }
        return false;
    }

    static async Task SaveCookiesAsync(IReadOnlyList<Microsoft.Playwright.Cookie> cookies, string path)
    {
        var mapped = cookies.Select(c => new { c.Name, c.Value, c.Domain, c.Path, c.SameSite, c.HttpOnly, c.Secure, c.Expires });
        var json = JsonSerializer.Serialize(mapped, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(path, json);
    }

    static async Task CallSharePointApiAsync(AppConfig cfg, IReadOnlyList<Microsoft.Playwright.Cookie> cookies)
    {
        var target = new Uri(new Uri(cfg.TargetSiteUrl), cfg.ApiCheckPath);
        Console.WriteLine($"Calling API: {target}");

        var handler = new System.Net.Http.HttpClientHandler
        {
            CookieContainer = new System.Net.CookieContainer(),
            AutomaticDecompression = System.Net.DecompressionMethods.GZip | System.Net.DecompressionMethods.Deflate
        };
        var baseUri = new Uri(cfg.TargetSiteUrl);

        foreach (var c in cookies)
        {
            var name   = c.Name  ?? string.Empty;
            var value  = c.Value ?? string.Empty;
            var domain = (c.Domain ?? baseUri.Host).TrimStart('.');
            var path   = string.IsNullOrEmpty(c.Path) ? "/" : c.Path;

            var netCookie = new System.Net.Cookie(name, value, path, domain);
            handler.CookieContainer.Add(baseUri, netCookie);
        }

        using var http = new HttpClient(handler);
        http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json;odata=nometadata"));

        var resp = await http.GetAsync(target);
        Console.WriteLine($"HTTP {(int)resp.StatusCode} {resp.ReasonPhrase}");
        var body = await resp.Content.ReadAsStringAsync();
        Console.WriteLine("Response:");
        Console.WriteLine(body);
    }
}
