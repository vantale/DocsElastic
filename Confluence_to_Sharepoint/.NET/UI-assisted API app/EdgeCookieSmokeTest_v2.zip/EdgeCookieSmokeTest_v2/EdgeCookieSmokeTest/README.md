# Edge UI-Assisted SharePoint Cookie Smoke Test (v2)

Fixes for your reported issues:
- **Line ~84**: Now passes the full `TargetSiteUrl` to `CookiesAsync` instead of `origin`.
- **Lines ~186-187**: Safer mapping from Playwright cookies to `System.Net.Cookie`:
  - Defaults `path` to `/` if null/empty.
  - Uses site host if `domain` is null; trims leading dot.
  - Guards `HttpOnly`/`Secure` assignments.
  - Skips `Expires` mapping (not needed for the request).

Build & Run:
```powershell
dotnet build .\EdgeCookieSmokeTest.sln
dotnet run --project .\EdgeCookieSmokeTest\EdgeCookieSmokeTest.csproj -- --site=https://yourtenant.sharepoint.com/sites/YourSite
```
