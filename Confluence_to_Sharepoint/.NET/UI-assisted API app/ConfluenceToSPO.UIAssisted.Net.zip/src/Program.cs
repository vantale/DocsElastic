using Microsoft.Playwright;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Web;

namespace ConfluenceToSPO.UIAssisted;

public class AppSettings
{
    public string SiteUrl { get; set; } = "https://YOURTENANT.sharepoint.com/sites/YourSite";
    public string StorageStatePath { get; set; } = "auth.json";
    public string UserDataDir { get; set; } = @"C:\Playwright\Profile";
    public string ManifestPath { get; set; } = "../out/manifest.json";
    public string CanvasTemplatePath { get; set; } = "canvasTemplate.json";
    public string AttachmentsLibraryTitle { get; set; } = "Documents";
    public string AttachmentsFolder { get; set; } = "ConfluenceAttachments";
    public string EnterpriseKeywordsFieldInternalName { get; set; } = "TaxKeyword";
}

public class Manifest
{
    public List<PageEntry> Pages { get; set; } = new();
}
public class PageEntry
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string Slug { get; set; } = "";
    public string HtmlPath { get; set; } = "";
    public List<string>? Labels { get; set; } = new();
}

public static class Program
{
    public static async Task<int> Main(string[] args)
    {
        var cmd = args.Length > 0 ? args[0].ToLowerInvariant() : "help";
        var cfg = JsonSerializer.Deserialize<AppSettings>(await File.ReadAllTextAsync(Path.Combine(AppContext.BaseDirectory, "appsettings.json"))) ?? new AppSettings();

        switch (cmd)
        {
            case "login":
                await LoginAsync(cfg);
                return 0;
            case "import":
                await ImportAsync(cfg);
                return 0;
            default:
                Console.WriteLine("Usage:");
                Console.WriteLine("  dotnet run -- login   # interactive login, saves storage state to auth.json");
                Console.WriteLine("  dotnet run -- import  # imports pages using storage state (UI-assisted API)");
                return 1;
        }
    }

    // ------------------ LOGIN ------------------
    private static async Task LoginAsync(AppSettings cfg)
    {
        using var pw = await Playwright.CreateAsync();
        var context = await pw.Chromium.LaunchPersistentContextAsync(cfg.UserDataDir, new()
        {
            Headless = false,
            Args = new[] { "--disable-blink-features=AutomationControlled" }
        });
        var page = await context.NewPageAsync();
        Console.WriteLine($"Opening {cfg.SiteUrl} ... sign in if prompted (MFA ok).");
        await page.GotoAsync(cfg.SiteUrl);
        await page.WaitForLoadStateAsync(LoadState.NetworkIdle);
        await context.StorageStateAsync(new() { Path = cfg.StorageStatePath });
        Console.WriteLine($"✅ Saved storage state to {cfg.StorageStatePath}");
    }

    // ------------------ IMPORT ------------------
    private static async Task ImportAsync(AppSettings cfg)
    {
        if (!File.Exists(cfg.StorageStatePath))
        {
            Console.WriteLine($"❌ Storage state '{cfg.StorageStatePath}' not found. Run: dotnet run -- login");
            return;
        }
        if (!File.Exists(cfg.ManifestPath))
        {
            Console.WriteLine($"❌ Manifest not found at '{cfg.ManifestPath}'");
            return;
        }
        if (!File.Exists(cfg.CanvasTemplatePath))
        {
            Console.WriteLine($"❌ Canvas template not found at '{cfg.CanvasTemplatePath}'. See canvasTemplate.README.md");
            return;
        }

        var templateText = await File.ReadAllTextAsync(cfg.CanvasTemplatePath);
        if (templateText.Contains("REPLACE_WITH_CAPTURED_CANVAS_JSON"))
        {
            Console.WriteLine("❌ canvasTemplate.json still contains the placeholder. Capture a real template per README and try again.");
            return;
        }
        var canvasTemplate = JsonNode.Parse(templateText) ?? throw new Exception("Canvas template JSON invalid");
        var manifest = JsonSerializer.Deserialize<Manifest>(await File.ReadAllTextAsync(cfg.ManifestPath)) ?? new Manifest();

        using var pw = await Playwright.CreateAsync();
        var browser = await pw.Chromium.LaunchAsync(new() { Headless = true });
        var context = await browser.NewContextAsync(new() { StorageStatePath = cfg.StorageStatePath });
        var page = await context.NewPageAsync();
        await page.GotoAsync(cfg.SiteUrl);
        await page.WaitForLoadStateAsync(LoadState.NetworkIdle);

        // Pass 1: ensure pages, build id->url
        var pageUrlById = new Dictionary<string, string>();
        foreach (var p in manifest.Pages)
        {
            var digest = await GetDigestAsync(page, cfg.SiteUrl);
            var ensure = await EnsureModernPageAsync(page, cfg.SiteUrl, digest, p);
            pageUrlById[p.Id] = ensure.AbsoluteUrl;
            Console.WriteLine($"[PAGE] {p.Slug}.aspx -> {ensure.AbsoluteUrl}");
        }

        // Pass 2: upload attachments and map old->new
        var oldToNewAttachment = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in manifest.Pages)
        {
            var html = await File.ReadAllTextAsync(p.HtmlPath);
            foreach (var oldUrl in ExtractAttachmentUrls(html))
            {
                var fileName = Uri.UnescapeDataString(new Uri("http://dummy" + oldUrl).Segments.Last());
                var local = FindAttachmentNear(p.HtmlPath, fileName);
                if (local == null) { Console.WriteLine($"[WARN] Missing attachment: {fileName}"); continue; }

                var digest = await GetDigestAsync(page, cfg.SiteUrl);
                var newAbs = await UploadAttachmentAsync(page, cfg.SiteUrl, digest, cfg.AttachmentsLibraryTitle, cfg.AttachmentsFolder, p.Slug, fileName, local);
                oldToNewAttachment[oldUrl] = newAbs;
                Console.WriteLine($"[FILE] {fileName} -> {newAbs}");
            }
        }

        // Pass 3: rewrite links, write content, publish, labels
        foreach (var p in manifest.Pages)
        {
            var html = await File.ReadAllTextAsync(p.HtmlPath);
            html = RewritePageIdLinks(html, pageUrlById);
            html = RewriteAttachmentLinks(html, oldToNewAttachment);

            var digest = await GetDigestAsync(page, cfg.SiteUrl);
            var ensure = await EnsureModernPageAsync(page, cfg.SiteUrl, digest, p);
            var canvas = BuildCanvasJson(canvasTemplate, html);

            await SavePageAsDraftAsync(page, cfg.SiteUrl, digest, ensure.Id, canvas);
            await PublishPageAsync(page, cfg.SiteUrl, digest, ensure.Id);

            if (p.Labels != null && p.Labels.Count > 0)
            {
                await SetLabelsAsync(page, cfg.SiteUrl, digest, ensure.ServerRelativeUrl, cfg.EnterpriseKeywordsFieldInternalName, p.Labels);
            }
            Console.WriteLine($"[PUBLISH] {p.Slug}.aspx");
        }

        Console.WriteLine("✅ Import complete.");
    }

    // ------------------ Helpers ------------------
    private static async Task<string> GetDigestAsync(IPage page, string siteUrl)
    {
        var j = await page.EvaluateAsync<JsonElement>($@"
            async () => {{
              const r = await fetch('{siteUrl}/_api/contextinfo', {{
                method: 'POST', headers: {{ 'Accept': 'application/json;odata=verbose' }}
              }}); return await r.json();
            }}");
        return j.GetProperty("d").GetProperty("GetContextWebInformation").GetProperty("FormDigestValue").GetString()!;
    }

    private static async Task<(int Id,string AbsoluteUrl,string ServerRelativeUrl)> EnsureModernPageAsync(IPage page, string siteUrl, string digest, PageEntry p)
    {
        var name = $"{p.Slug}.aspx";
        // Try existing
        var exists = await page.EvaluateAsync<int>($@"
            async () => {{
              const r = await fetch('{siteUrl}/_api/web/GetFileByServerRelativeUrl(\'/SitePages/{name}\')?$select=ServerRelativeUrl,ListItemAllFields/Id&$expand=ListItemAllFields', {{
                headers: {{ 'Accept':'application/json;odata=nometadata' }}
              }});
              return r.ok ? 1 : 0;
            }}");
        if (exists == 1)
        {
            var info = await page.EvaluateAsync<JsonElement>($@"
              async () => {{
                const r = await fetch('{siteUrl}/_api/web/GetFileByServerRelativeUrl(\'/SitePages/{name}\')?$select=ServerRelativeUrl,ListItemAllFields/Id&$expand=ListItemAllFields', {{
                  headers: {{ 'Accept':'application/json;odata=nometadata' }}
                }});
                return await r.json();
              }}");
            var srel = info.GetProperty("ServerRelativeUrl").GetString()!;
            var id = info.GetProperty("ListItemAllFields").GetProperty("Id").GetInt32();
            var abs = $"{new Uri(siteUrl).GetLeftPart(UriPartial.Authority)}{srel}";
            return (id, abs, srel);
        }

        // Create
        var created = await PostJsonAsync(page, $"{siteUrl}/_api/sitepages/pages", digest, new {
            Title = string.IsNullOrWhiteSpace(p.Title) ? p.Slug : p.Title,
            PageLayoutType = "Article",
            PromotedState = 0
        });
        var pageId = created.GetProperty("Id").GetInt32();
        var fileRef = created.TryGetProperty("Url", out var urlProp) ? urlProp.GetString()! : created.GetProperty("ServerRelativeUrl").GetString()!;
        var absUrl = $"{new Uri(siteUrl).GetLeftPart(UriPartial.Authority)}{fileRef}";
        return (pageId, absUrl, fileRef);
    }

    private static async Task<string> UploadAttachmentAsync(IPage page, string siteUrl, string digest, string libraryTitle, string folderRoot, string slug, string fileName, string localPath)
    {
        var folderUrl = $"/{libraryTitle}/{folderRoot}/{slug}";
        await EnsureFolderAsync(page, siteUrl, digest, folderUrl);

        var bytes = await File.ReadAllBytesAsync(localPath);
        var base64 = Convert.ToBase64String(bytes);
        var uploadUrl = $"{siteUrl}/_api/web/GetFolderByServerRelativeUrl('{folderUrl}')/Files/add(url='{HttpUtility.UrlEncode(fileName)}',overwrite=true)";

        var res = await page.EvaluateAsync<JsonElement>($@"
            async () => {{
              const binary = Uint8Array.from(atob('{base64}'), c => c.charCodeAt(0));
              const r = await fetch('{uploadUrl}', {{
                method: 'POST',
                headers: {{ 'Accept': 'application/json;odata=nometadata', 'X-RequestDigest': '{digest}' }},
                body: binary
              }});
              return await r.json();
            }}");
        var serverRel = res.GetProperty("ServerRelativeUrl").GetString()!;
        return $"{new Uri(siteUrl).GetLeftPart(UriPartial.Authority)}{serverRel}";
    }

    private static async Task EnsureFolderAsync(IPage page, string siteUrl, string digest, string serverRelativeUrl)
    {
        await page.EvaluateAsync($@"
            async () => {{
              await fetch('{siteUrl}/_api/web/folders', {{
                method:'POST',
                headers: {{ 'Accept':'application/json;odata=nometadata', 'Content-Type':'application/json;odata=nometadata', 'X-RequestDigest': '{digest}' }},
                body: JSON.stringify({{ ServerRelativeUrl: '{serverRelativeUrl}' }})
              }});
            }}");
    }

    private static async Task SavePageAsDraftAsync(IPage page, string siteUrl, string digest, int pageId, JsonNode canvas)
        => await PostJsonAsync(page, $"{siteUrl}/_api/sitepages/pages({pageId})/SavePageAsDraft", digest, canvas);

    private static async Task PublishPageAsync(IPage page, string siteUrl, string digest, int pageId)
        => await PostJsonAsync(page, $"{siteUrl}/_api/sitepages/pages({pageId})/Publish", digest, new { });

    private static async Task SetLabelsAsync(IPage page, string siteUrl, string digest, string serverRelativeUrl, string fieldInternalName, IList<string> labels)
    {
        var setUrl = $"{siteUrl}/_api/web/GetFileByServerRelativeUrl('{serverRelativeUrl}')/ListItemAllFields";
        await page.EvaluateAsync($@"
            async () => {{
              await fetch('{setUrl}', {{
                method:'POST',
                headers: {{
                  'Accept':'application/json;odata=nometadata',
                  'Content-Type':'application/json;odata=nometadata',
                  'IF-MATCH':'*',
                  'X-HTTP-Method':'MERGE',
                  'X-RequestDigest':'{digest}'
                }},
                body: JSON.stringify({{ '{fieldInternalName}': '{string.Join(";", labels)}' }})
              }});
            }}");
    }

    private static IEnumerable<string> ExtractAttachmentUrls(string html)
        => Regex.Matches(html, @"['""](\/download\/attachments\/[^'""\s]+)['""]")
           .Select(m => m.Groups[1].Value).Distinct();

    private static string? FindAttachmentNear(string htmlPath, string fileName)
    {
        var dir = new DirectoryInfo(Path.GetDirectoryName(htmlPath)!);
        for (int i=0; i<5 && dir!=null; i++, dir = dir.Parent!)
        {
            var root = Path.Combine(dir.FullName, "attachments");
            if (Directory.Exists(root))
            {
                var cand = Directory.EnumerateFiles(root, fileName, SearchOption.AllDirectories).FirstOrDefault();
                if (cand != null) return cand;
            }
        }
        return null;
    }

    private static string RewritePageIdLinks(string html, IDictionary<string,string> idToUrl)
        => Regex.Replace(html, "href=\"[^\"]*pageId=(\\d+)[^\"]*\"", m =>
           idToUrl.TryGetValue(m.Groups[1].Value, out var u) ? $"href=\"{u}\"" : m.Value,
           RegexOptions.IgnoreCase);

    private static string RewriteAttachmentLinks(string html, IDictionary<string,string> map)
    {
        foreach (var kv in map)
        {
            html = Regex.Replace(html, $"(href|src)=\"{Regex.Escape(kv.Key)}\"", $"$1=\"{kv.Value}\"", RegexOptions.IgnoreCase);
        }
        return html;
    }

    private static JsonNode BuildCanvasJson(JsonNode template, string html)
    {
        // The template is the full body expected by SavePageAsDraft; replace {{HTML}} in it.
        var json = template.ToJsonString();
        json = json.Replace("{{HTML}}", html.Replace("\\", "\\\\").Replace("\"","\\\"").Replace("\n","\\n"));
        return JsonNode.Parse(json)!;
    }

    private static async Task<JsonElement> PostJsonAsync(IPage page, string url, string digest, object body)
    {
        var payload = JsonSerializer.Serialize(body);
        return await page.EvaluateAsync<JsonElement>($@"
            async () => {{
              const r = await fetch('{url}', {{
                method:'POST',
                headers: {{
                  'Accept':'application/json;odata=nometadata',
                  'Content-Type':'application/json;odata=nometadata',
                  'X-RequestDigest':'{digest}'
                }},
                body: `{payload}`
              }});
              return await r.json();
            }}");
    }
}
