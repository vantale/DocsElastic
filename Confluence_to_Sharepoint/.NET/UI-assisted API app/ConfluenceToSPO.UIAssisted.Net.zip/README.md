# Confluence → SharePoint (UI-Assisted API, .NET 8 + Playwright)

This project logs into SharePoint **once** (interactive) and then imports pages by calling SharePoint’s REST endpoints **from the logged-in browser context**. No tenant app consent is required.

## What’s inside
- `login` command — opens a real browser, you sign in (MFA ok), saves **storage state** to `auth.json`.
- `import` command — uses `auth.json` to call SharePoint REST and:
  - create/reuse modern pages,
  - upload attachments,
  - set page HTML via **CanvasContent1** (Text web part),
  - publish pages,
  - set labels (Enterprise Keywords or custom field).

> This reuses the **user session** exactly like the SharePoint UI — but without clicking through the designer.

---

## 1) Prereqs

- .NET 8 SDK
- Playwright browsers (one time):
  ```bash
  dotnet build
  pwsh ./src/bin/Debug/net8.0/playwright.ps1 install
  ```
- SharePoint site ready; your user can create/publish pages (see permissions guide).

---

## 2) Configure

Edit `src/appsettings.json`:
```json
{
  "SiteUrl": "https://YOURTENANT.sharepoint.com/sites/YourSite",
  "StorageStatePath": "auth.json",
  "UserDataDir": "C:\\Playwright\\Profile",
  "ManifestPath": "../out/manifest.json",
  "CanvasTemplatePath": "canvasTemplate.json",
  "AttachmentsLibraryTitle": "Documents",
  "AttachmentsFolder": "ConfluenceAttachments",
  "EnterpriseKeywordsFieldInternalName": "TaxKeyword"
}
```

Provide your `manifest.json` (see `examples/manifest.sample.json`) and HTML files.

---

## 3) Capture a **Canvas** template (one time)

You need a `canvasTemplate.json` containing the exact JSON SharePoint expects for a page with a single **Text** web part. Capture it from your tenant:

1. Create a new modern page with a **Text** web part. In the editor, type a unique token, e.g. `{{HTML}}`.
2. Open **DevTools → Network**. Click **Publish**. Find the request to:  
   `/_api/sitepages/pages({id})/SavePageAsDraft`
3. Copy the **request body JSON**, paste into `src/canvasTemplate.json`.
4. Replace the text content portion with literally `{{HTML}}`. Make sure the file stays **valid JSON**.
5. Save.

> The importer will replace `{{HTML}}` with your final HTML per page.

---

## 4) Login once

```bash
cd src
dotnet run -- login
```
A browser opens at your site; sign in (MFA ok). The app saves `auth.json` (storage state).

---

## 5) Import

```bash
dotnet run -- import
```
What happens:
- Ensures a modern page per manifest entry (creates or reuses `{slug}.aspx`).
- Uploads referenced attachments to `/Documents/ConfluenceAttachments/{slug}/`.
- Rewrites Confluence links (`pageId=` and `/download/attachments/`) to new SPO URLs.
- Applies **CanvasContent1** from your template with the page HTML and **publishes**.
- Writes labels to `TaxKeyword` (or the field you configured).

---

## 6) Notes & limits

- This approach uses the **user’s session** (no tenant app consent). Conditional Access must allow the session.
- The **canvas template** is tenant-specific; capture once and keep it with the project.
- For very large files, extend the uploader to use **chunked** upload endpoints.
- Add retries/backoff for 429/503 if you increase throughput.

---

## 7) Manifest sample

See `examples/manifest.sample.json`. Shape:
```json
{
  "pages": [
    {
      "id": "12345",
      "title": "Welcome",
      "slug": "welcome",
      "htmlPath": "../out/pages/welcome-12345.html",
      "labels": ["howto","policy"]
    }
  ]
}
```

---

## 8) Safety

- `auth.json` represents your login — keep it secure. Don’t commit to source control.
- The tool overwrites page content and attachments idempotently; run on a pilot first.
