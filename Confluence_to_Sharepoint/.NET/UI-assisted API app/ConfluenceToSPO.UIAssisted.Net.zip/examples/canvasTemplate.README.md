# Capturing canvasTemplate.json

1) Create a modern page with a single **Text** web part.
2) Type `{{HTML}}` in the text box.
3) DevTools → Network → Publish → find `SavePageAsDraft` request.
4) Copy the **request body JSON** into `src/canvasTemplate.json`.
5) Replace the text value with `{{HTML}}`. Keep valid JSON.
