# Edge UI-Assisted SharePoint Cookie Smoke Test (C#/.NET 8) — Fixed Cookie Types

This build fixes the `Cookie` ambiguity by aliasing:
```csharp
using PwCookie = Microsoft.Playwright.Cookie;
using NetCookie = System.Net.Cookie;
```

## Build & Run
```powershell
dotnet build .\EdgeCookieSmokeTest.sln
dotnet run --project .\EdgeCookieSmokeTest\EdgeCookieSmokeTest.csproj -- --site=https://yourtenant.sharepoint.com/sites/YourSite
```
The app starts/attaches to system Edge with remote debugging, waits for FedAuth+rtFa, saves `cookies.json`, and calls `/_api/web/title`.
