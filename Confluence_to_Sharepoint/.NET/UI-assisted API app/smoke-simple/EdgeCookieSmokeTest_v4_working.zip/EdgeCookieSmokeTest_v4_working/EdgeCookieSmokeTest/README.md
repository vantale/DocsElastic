# EdgeCookieSmokeTest v4 — Robust DevTools Attach

This version fixes "Could not reach Edge DevTools endpoint" by:
- Launching **Edge in an isolated user-data-dir**, avoiding single-instance conflicts.
- Supporting **dynamic port** (`RemoteDebuggingPort = 0`) and discovering the port from `DevToolsActivePort`.
- Probing common ports 9222–9230 if an instance is already running.
- Clear error tips and a manual launch command.

## Quick start
```powershell
dotnet build .\EdgeCookieSmokeTest.sln
dotnet run --project .\EdgeCookieSmokeTest\EdgeCookieSmokeTest.csproj -- --site=https://yourtenant.sharepoint.com/sites/YourSite
```
To let Edge choose a port dynamically, set `"RemoteDebuggingPort": 0` in `appsettings.json`.
