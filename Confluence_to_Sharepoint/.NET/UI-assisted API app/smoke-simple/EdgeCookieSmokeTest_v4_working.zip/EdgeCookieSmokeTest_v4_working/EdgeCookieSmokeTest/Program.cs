// Program.cs — EdgeCookieSmokeTest (fixed)
// .NET 8, Playwright client only (CDP attach to system Edge)

using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Linq;
using Microsoft.Playwright;

// IMPORTANT: Playwright cookies come as BrowserContextCookiesResult (not Cookie).
using PwCookie = Microsoft.Playwright.BrowserContextCookiesResult;
using NetCookie = System.Net.Cookie;

internal sealed class AppConfig
{
    public string TargetSiteUrl { get; set; } = "";
    public string ApiCheckPath { get; set; } = "/_api/web/title";
    public int RemoteDebuggingPort { get; set; } = 9222; // set 0 to auto-pick
    public int WaitTimeoutSeconds { get; set; } = 300;
    public string CookiesOutputPath { get; set; } = "cookies.json";
    public string? EdgeExecutable { get; set; } = null;  // null → auto-detect
    public string ProfileDirectory { get; set; } = "Default";
}

internal static class Program
{
    private static async Task<int> Main(string[] args)
    {
        try
        {
            var cfg = LoadConfig();
            // CLI override: --site=...
            var siteArg = args.FirstOrDefault(a => a.StartsWith("--site=", StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrWhiteSpace(siteArg))
            {
                cfg.TargetSiteUrl = siteArg.Split('=', 2)[1].Trim('"');
            }

            if (string.IsNullOrWhiteSpace(cfg.TargetSiteUrl))
            {
                Console.Error.WriteLine("✖ TargetSiteUrl is empty. Set it in appsettings.json or pass --site=...");
                return 2;
            }

            var baseUri = new Uri(cfg.TargetSiteUrl);

            // 1) Launch Edge with DevTools if needed (isolated user-data-dir to avoid single-instance merge)
            var port = cfg.RemoteDebuggingPort == 0 ? GetFreeTcpPort() : cfg.RemoteDebuggingPort;
            var edgeExe = cfg.EdgeExecutable ?? GuessEdgePath() ?? "msedge.exe";
            var userDataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "EdgeCookieSmokeTest",
                "TempProfile_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(userDataDir);

            var argsEdge =
                $"--remote-debugging-port={port} " +
                $"--user-data-dir=\"{userDataDir}\" " +
                $"--profile-directory={cfg.ProfileDirectory} " +
                $"--no-first-run --no-default-browser-check " +
                $"\"{cfg.TargetSiteUrl}\"";

            var edge = Process.Start(new ProcessStartInfo
            {
                FileName = edgeExe,
                Arguments = argsEdge,
                UseShellExecute = false
            }) ?? throw new InvalidOperationException("Failed to start Edge.");

            Console.WriteLine($"▶ Launched Edge: {edgeExe} (pid {edge.Id}), DevTools on :{port}");

            // 2) Attach Playwright (CDP) to Edge
            using var pw = await Playwright.CreateAsync();
            // Probe until DevTools endpoint is available
            await WaitUntilAsync(async () =>
            {
                try
                {
                    // Quick HEAD probe
                    using var http = new HttpClient();
                    http.Timeout = TimeSpan.FromMilliseconds(500);
                    var resp = await http.GetAsync($"http://localhost:{port}/json/version");
                    return resp.IsSuccessStatusCode;
                }
                catch { return false; }
            }, TimeSpan.FromSeconds(15), TimeSpan.FromMilliseconds(250));

            await using var browser = await pw.Chromium.ConnectOverCDPAsync($"http://localhost:{port}");
            var context = browser.Contexts.FirstOrDefault() ?? await browser.NewContextAsync();
            var page = context.Pages.FirstOrDefault() ?? await context.NewPageAsync();

            // Navigate if we attached before the page loaded
            if (string.IsNullOrEmpty(page.Url) || !page.Url.StartsWith(cfg.TargetSiteUrl, StringComparison.OrdinalIgnoreCase))
            {
                await page.GotoAsync(cfg.TargetSiteUrl, new() { WaitUntil = WaitUntilState.NetworkIdle, Timeout = 0 });
            }
            Console.WriteLine("ℹ Please complete the login in Edge if required (MFA, redirects, etc.).");

            // 3) Wait for FedAuth + rtFa to appear (IMPORTANT: async lambda returns Task<bool>)
            await WaitUntilAsync(async () =>
            {
                var cookies = await context.CookiesAsync(new[] { cfg.TargetSiteUrl });
                var names = cookies.Select(c => c.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
                return names.Contains("FedAuth") && names.Contains("rtFa");
            }, TimeSpan.FromSeconds(cfg.WaitTimeoutSeconds), TimeSpan.FromMilliseconds(500));

            // 4) Read cookies and save to file (type: IReadOnlyList<BrowserContextCookiesResult>)
            var pwCookies = await context.CookiesAsync(new[] { cfg.TargetSiteUrl });
            await SaveCookiesAsync(pwCookies, cfg.CookiesOutputPath);
            Console.WriteLine($"✅ Login detected (FedAuth + rtFa). Saved → {cfg.CookiesOutputPath}");

            // 5) Call SharePoint REST using CookieContainer
            await CallSharePointApiAsync(cfg, pwCookies);
            Console.WriteLine("✅ API probe completed.");

            return 0;
        }
        catch (TimeoutException tex)
        {
            Console.Error.WriteLine("⏳ Timeout: " + tex.Message);
            return 3;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("✖ Error: " + ex);
            return 1;
        }
    }

    private static AppConfig LoadConfig()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        if (!File.Exists(path)) return new AppConfig();
        var json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<AppConfig>(json, new JsonSerializerOptions
        {
            ReadCommentHandling = JsonCommentHandling.Skip,
            AllowTrailingCommas = true,
            PropertyNameCaseInsensitive = true
        }) ?? new AppConfig();
    }

    private static async Task WaitUntilAsync(Func<Task<bool>> predicate, TimeSpan timeout, TimeSpan pollInterval)
    {
        var sw = Stopwatch.StartNew();
        while (sw.Elapsed < timeout)
        {
            if (await predicate().ConfigureAwait(false)) return;
            await Task.Delay(pollInterval).ConfigureAwait(false);
        }
        throw new TimeoutException("Condition not met within the allotted time.");
    }

    private static async Task SaveCookiesAsync(IReadOnlyList<PwCookie> cookies, string path)
    {
        var opts = new JsonSerializerOptions { WriteIndented = true };
        await File.WriteAllTextAsync(path, JsonSerializer.Serialize(cookies, opts));
    }

    private static async Task CallSharePointApiAsync(AppConfig cfg, IReadOnlyList<PwCookie> cookies)
    {
        var baseUri = new Uri(cfg.TargetSiteUrl);
        var target = new Uri(baseUri, cfg.ApiCheckPath);

        var handler = new HttpClientHandler
        {
            CookieContainer = new CookieContainer(),
            AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate
        };

        // Map Playwright cookie → System.Net.Cookie
        foreach (var c in cookies)
        {
            var name = c.Name ?? string.Empty;
            var value = c.Value ?? string.Empty;
            var domain = (c.Domain ?? baseUri.Host).TrimStart('.');
            var path = string.IsNullOrEmpty(c.Path) ? "/" : c.Path;

            var netCookie = new NetCookie(name, value, path, domain);
            // NOTE: CookieContainer ignores HttpOnly/Secure for sending; safe to omit.
            handler.CookieContainer.Add(baseUri, netCookie);
        }

        using var http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(60) };
        http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        http.DefaultRequestHeaders.Add("Accept", "application/json;odata=nometadata");

        using var resp = await http.GetAsync(target);
        Console.WriteLine($"HTTP {(int)resp.StatusCode} {resp.ReasonPhrase}");
        var body = await resp.Content.ReadAsStringAsync();
        Console.WriteLine(body);
    }

    private static int GetFreeTcpPort()
    {
        var l = new TcpListener(IPAddress.Loopback, 0);
        l.Start();
        var port = ((IPEndPoint)l.LocalEndpoint).Port;
        l.Stop();
        return port;
    }

    private static string? GuessEdgePath()
    {
        var candidates = new[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Microsoft", "Edge", "Application", "msedge.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Microsoft", "Edge", "Application", "msedge.exe"),
        };
        return candidates.FirstOrDefault(File.Exists);
    }
}
