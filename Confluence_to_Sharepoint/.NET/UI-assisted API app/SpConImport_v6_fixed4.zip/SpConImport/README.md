# SpConImport v6 – Confluence → SharePoint (Auth: WebView2 / Playwright / MSAL)

## Co nowego
- Przełącznik **Auth mode**:
  - **WebView2 (cookies)** – logowanie w osadzonym oknie Edge i przechwycenie FedAuth/rtFa.
  - **Playwright (cookies)** – prawdziwa przeglądarka (Chromium), logujesz się, a my czytamy FedAuth/rtFa.
  - **MSAL (system browser / Device Code)** – oficjalny OAuth; nagłówki **Bearer** zamiast cookies.

- Ten sam silnik importu: nowoczesne **Site Pages**, upload **załączników**, przepinanie **linków**, **etykiety** i **komentarze**.

## Pakiety
- Microsoft.Web.WebView2
- Microsoft.Playwright
- Microsoft.Identity.Client
- HtmlAgilityPack

## Pierwsze uruchomienie (Playwright)
Playwright przy pierwszym starcie dociągnie przeglądarki – aplikacja robi to automatycznie.

## MSAL – konfiguracja
W Entra ID utwórz **Public client** (native), zapisz **TenantId** i **ClientId**.
- Delegated permissions do SharePoint Online (np. `AllSites.FullControl`) i **Admin consent**.
- W trybie interactive dodaj redirect URI `http://localhost`.
W UI wpisz TenantId/ClientId. Możesz użyć Device Code (checkbox).

## Build & run
```powershell
dotnet build .\SpConImport\SpConImport.sln
dotnet run --project .\SpConImport\src\SpConImport.App\SpConImport.App.csproj
```
