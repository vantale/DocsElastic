using Microsoft.Playwright;
using System.Net;

namespace SpConImport.Services
{
    public sealed class PlaywrightAuthService : IAsyncDisposable
    {
        private IPlaywright? _pw;
        private IBrowserContext? _ctx;
        private readonly string _profileDir;

        public PlaywrightAuthService(string profileDir) => _profileDir = profileDir;

        public async Task<CookieContainer> LoginAndGetCookiesAsync(string siteUrl, Action<string>? log = null)
        {
            try { Microsoft.Playwright.Program.Main(new[] { "install" }); } catch { }

            _pw = await Playwright.CreateAsync();
            _ctx = await _pw.Chromium.LaunchPersistentContextAsync(
                _profileDir,
                new BrowserTypeLaunchPersistentContextOptions
                {
                    Headless = false,
                    ViewportSize = null
                });

            var page = _ctx.Pages.FirstOrDefault() ?? await _ctx.NewPageAsync();
            await page.GotoAsync(siteUrl, new() { WaitUntil = WaitUntilState.NetworkIdle });
            log?.Invoke("Zaloguj się w oknie przeglądarki. Aplikacja poczeka na sesję…");

            var deadline = DateTime.UtcNow.AddMinutes(2);
            var siteHost = new Uri(siteUrl).Host;

            while (DateTime.UtcNow < deadline)
            {
                var cookies = await _ctx.CookiesAsync();
                var fed = cookies.Any(c => c.Name.Equals("FedAuth", StringComparison.OrdinalIgnoreCase));
                var rtfa = cookies.Any(c => c.Name.Equals("rtFa", StringComparison.OrdinalIgnoreCase));

                if (fed && rtfa)
                {
                    var jar = new CookieContainer();
                    foreach (var c in cookies)
                    {
                        var domain = c.Domain?.TrimStart('.') ?? siteHost;
                        if (!siteHost.EndsWith(domain, StringComparison.OrdinalIgnoreCase)) continue;

                        var cookie = new System.Net.Cookie(
                            c.Name, c.Value,
                            string.IsNullOrEmpty(c.Path) ? "/" : c.Path,
                            domain)
                        {
                            Secure = c.Secure,
                            HttpOnly = c.HttpOnly
                        };
                        try { var exp = System.Convert.ToDouble(c.Expires); if (exp > 0) cookie.Expires = DateTimeOffset.FromUnixTimeSeconds((long)exp).UtcDateTime; } catch { }

                        try { jar.Add(cookie); } catch { }
                    }
                    return jar;
                }
                await Task.Delay(1000);
            }

            throw new Exception("Nie wykryto FedAuth/rtFa w czasie 2 minut.");
        }

        public async ValueTask DisposeAsync()
        {
            if (_ctx is not null) await _ctx.CloseAsync();
            _pw?.Dispose();
        }
    }
}
