using Microsoft.Identity.Client;

namespace SpConImport.Services
{
    public class MsalAuthService
    {
        private readonly string _tenantId;
        private readonly string _clientId;

        public MsalAuthService(string tenantId, string clientId)
        {
            _tenantId = tenantId;
            _clientId = clientId;
        }

        public async Task<string> AcquireTokenAsync(string siteUrl, bool useDeviceCode, Action<string>? log = null)
        {
            var authority = $"https://login.microsoftonline.com/{_tenantId}";
            var resource = new Uri(siteUrl).GetLeftPart(UriPartial.Authority); // e.g., https://contoso.sharepoint.com
            var scopes = new[] { $"{resource}/AllSites.FullControl" };

            if (useDeviceCode)
            {
                var pca = PublicClientApplicationBuilder.Create(_clientId)
                    .WithAuthority(authority)
                    .Build();

                var result = await pca.AcquireTokenWithDeviceCode(scopes, dev =>
                {
                    log?.Invoke(dev.Message);
                    return Task.CompletedTask;
                }).ExecuteAsync();

                return result.AccessToken;
            }
            else
            {
                var pca = PublicClientApplicationBuilder.Create(_clientId)
                    .WithAuthority(authority)
                    .WithRedirectUri("http://localhost")
                    .Build();

                var result = await pca.AcquireTokenInteractive(scopes)
                    .WithUseEmbeddedWebView(false) // system browser
                    .ExecuteAsync();

                return result.AccessToken;
            }
        }
    }
}
