using System.Net.Http;
using System;
namespace SpConImport.Utils
{
    public static class HttpClientFactoryWithCookies
    {
        public static HttpClient Create(HttpMessageHandler handler)
        {
            var client = new HttpClient(handler);
            client.Timeout = TimeSpan.FromMinutes(10);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "application/json;odata=verbose");
            return client;
        }
    }
}
