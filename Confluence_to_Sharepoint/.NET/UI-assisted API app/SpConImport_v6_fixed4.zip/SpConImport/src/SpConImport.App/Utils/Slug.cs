using System.Text.RegularExpressions;
namespace SpConImport.Utils
{
    public static class Slug
    {
        public static string FromTitle(string title)
        {
            if (string.IsNullOrWhiteSpace(title)) title = "page";
            var s = title.Trim().ToLowerInvariant();
            s = Regex.Replace(s, @"\s+", "-");
            s = Regex.Replace(s, @"[^a-z0-9\-_]+", "");
            if (string.IsNullOrWhiteSpace(s)) s = "page";
            return s;
        }
        public static string FromFilename(string filenameNoExt) => FromTitle(filenameNoExt);
    }
}
