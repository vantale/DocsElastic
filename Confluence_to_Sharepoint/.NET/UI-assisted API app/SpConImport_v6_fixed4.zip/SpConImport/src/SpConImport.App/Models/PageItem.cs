using System.Collections.Generic;
namespace SpConImport.Models
{
    public class PageItem
    {
        public string SourcePath { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Slug { get; set; } = string.Empty;
        public string Html { get; set; } = string.Empty;
        public List<string> ImagePaths { get; set; } = new();
        public List<string> FileLinks { get; set; } = new();
        public List<string> InternalLinks { get; set; } = new();
        public List<string> Labels { get; set; } = new();
        public List<string> Comments { get; set; } = new();
    }
}
