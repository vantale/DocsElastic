namespace SpConImport.Models
{
    public class ImportOptions
    {
        public string SiteUrl { get; set; } = string.Empty;
        public string LibraryTitleOrServerRelative { get; set; } = "SiteAssets";
        public string Subfolder { get; set; } = "ConfluenceImport";
        public bool CreateModernPages { get; set; } = true;
        public bool UploadAttachments { get; set; } = true;
        public bool RewriteLinks { get; set; } = true;
        public string? ConfluenceXmlPath { get; set; }
        public string SitePagesLibraryTitle { get; set; } = "Site Pages";
        public string LabelsFieldName { get; set; } = "ConfluenceLabels";
        public AuthMode AuthMode { get; set; } = AuthMode.WebView2Cookies;
        // MSAL
        public string? TenantId { get; set; }
        public string? ClientId { get; set; }
        public bool UseDeviceCode { get; set; } = false;
    }

    public enum AuthMode { WebView2Cookies, PlaywrightCookies, MsalBrowser }
}
