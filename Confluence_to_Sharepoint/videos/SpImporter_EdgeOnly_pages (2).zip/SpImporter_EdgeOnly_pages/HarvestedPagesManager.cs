﻿namespace SpImporter_EdgeOnly_pages;

internal class HarvestedPagesManager
{
    // Umieść np. w Program.cs
    // Wymagane usingi:
    // using System.IO;
    // using System.Linq;
    // using System.Collections.Generic;

    public readonly record struct ImportCandidate(string Name, string FullPath, int HtmlCount);

    /// <summary>
    /// Skanuje katalog HarvestedPages (domyślny lub z configu) i zwraca listę
    /// podkatalogów będących kandydatami do importu (zawierają pliki HTML).
    /// Metoda również wypisuje listę kandydatów na konsolę.
    /// </summary>
    /// <param name="harvestedRootFromConfig">
    /// Opcjonalnie ścieżka z appsettings (np. Config["HarvestedPages:Root"]).
    /// Gdy pusta/null, użyje domyślnej wartości poniżej.
    /// </param>
    public static IReadOnlyList<ImportCandidate> ListHarvestedPageCandidates(string? harvestedRootFromConfig = null)
    {
        // Domyślna lokalizacja – możesz podmienić lub zostawić jako fallback.
        var defaultRoot = @"C:\Users\kamil\OneDrive\Documents\CONFLUENCE.SHAREPOINT\HarvestedPages";
        var root = string.IsNullOrWhiteSpace(harvestedRootFromConfig) ? defaultRoot : harvestedRootFromConfig!;
        root = Path.GetFullPath(Environment.ExpandEnvironmentVariables(root));

        var attrSkip = FileAttributes.System | FileAttributes.Hidden;
        var optsNoRecurse = new EnumerationOptions
        {
            RecurseSubdirectories = false,
            IgnoreInaccessible = true,
            AttributesToSkip = attrSkip
        };

        var candidates = new List<ImportCandidate>();

        // 1) Jeśli w katalogu głównym są HTML-e, potraktuj go też jako kandydata.
        var rootHtml = Directory.Exists(root)
            ? Directory.EnumerateFiles(root, "*.*", optsNoRecurse)
                .Where(IsHtml)
                .ToArray()
            : Array.Empty<string>();

        if (rootHtml.Length > 0)
        {
            var rootName = Path.GetFileName(root.TrimEnd(Path.DirectorySeparatorChar)) is { Length: > 0 } n ? n : root;
            candidates.Add(new ImportCandidate(rootName, root, rootHtml.Length));
        }

        // 2) Przeskanuj tylko bezpośrednie podkatalogi (typowy export stron).
        if (Directory.Exists(root))
        {
            foreach (var dir in Directory.GetDirectories(root, "*", optsNoRecurse))
            {
                var name = Path.GetFileName(dir);

                // Pomijamy oczywiste katalogi tymczasowe/„techniczne”.
                if (name.StartsWith("~") || name.StartsWith("_") || name.Equals("Attachments", StringComparison.OrdinalIgnoreCase))
                    continue;

                var htmls = Directory.EnumerateFiles(dir, "*.*", optsNoRecurse)
                    .Where(IsHtml)
                    .ToArray();

                if (htmls.Length > 0)
                {
                    candidates.Add(new ImportCandidate(name, dir, htmls.Length));
                }
            }
        }
        else
        {
            Console.Error.WriteLine($"[HarvestedPages] Nie znaleziono katalogu: {root}");
        }

        // Sortowanie alfabetyczne po nazwie
        candidates.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));

        // Wypisanie listy kandydatów
        Console.WriteLine();
        Console.WriteLine($"[HarvestedPages] root: {root}");
        if (candidates.Count == 0)
        {
            Console.WriteLine("  brak kandydatów (nie znaleziono folderów z plikami .html w katalogu głównym ani w jego podfolderach).");
        }
        else
        {
            Console.WriteLine("  Kandydaci do importu:");
            for (int i = 0; i < candidates.Count; i++)
            {
                var c = candidates[i];
                Console.WriteLine($"  [{i + 1,2}] {c.Name,-40} | HTML: {c.HtmlCount,3} | {c.FullPath}");
            }
        }

        return candidates;

        static bool IsHtml(string path)
        {
            var ext = Path.GetExtension(path);
            return ext.Equals(".html", StringComparison.OrdinalIgnoreCase)
                || ext.Equals(".htm", StringComparison.OrdinalIgnoreCase)
                || ext.Equals(".xhtml", StringComparison.OrdinalIgnoreCase);
        }
    }

}