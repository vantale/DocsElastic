using Microsoft.Playwright;
using static SpImporter_EdgeOnly_pages.HarvestedPagesManager;

internal class Worker
{
    public async Task ExecuteAsync(IBrowserContext ctx, IPage page, Config cfg, ImportCandidate selectedCandidate, string targetFolder)
    {
        bool docsChunkOpen = false;
        bool createChunkOpen = false;

        // ------------ Documents upload ------------
        var docsUrl = $"{cfg.SiteUrl}/Shared%20Documents/Forms/AllItems.aspx";
        await page.GotoAsync(docsUrl, new() { WaitUntil = WaitUntilState.DOMContentLoaded });
        Console.WriteLine("[Nav] Documents opened.");

        // CHUNK: upload do Documents
        await ctx.Tracing.StartChunkAsync(new TracingStartChunkOptions { Title = "docs-upload" });
        docsChunkOpen = true;
        try
        {
            await EnsureFolderAsync(page, cfg.RootInDocuments);
            await OpenFolderAsync(page, cfg.RootInDocuments);
            await EnsureFolderAsync(page, targetFolder);
            await OpenFolderAsync(page, targetFolder);

            var src = ResolveAttachmentsSource(selectedCandidate.FullPath);
            var files = Directory.GetFiles(src, "*", SearchOption.TopDirectoryOnly);
            Console.WriteLine($"[Upload] {files.Length} file(s) from: {src}");
            if (files.Length > 0)
            {
                await UploadFilesAsync(page, files);
                Console.WriteLine("[Upload] Done.");
            }
            else
            {
                Console.WriteLine("[Upload] Nothing to upload.");
            }

            Console.WriteLine("[Result] " + $"{cfg.SiteUrl}/Shared%20Documents/{Uri.EscapeDataString(cfg.RootInDocuments)}/{Uri.EscapeDataString(targetFolder)}");
        }
        finally
        {
            if (docsChunkOpen)
            {
                try
                {
                    await ctx.Tracing.StopChunkAsync(new() { Path = Path.Combine(Diag.RunDir, "trace-docs.zip") });
                }
                catch (Exception ex)
                {
                    Console.WriteLine("[TRACE] stop chunk (docs) failed: " + ex.Message);
                }
                docsChunkOpen = false;
            }
        }

        // ------------ Tworzenie strony ------------
        var builder = new ModernPageBuilder(page, cfg.SiteUrl, cfg.RootInDocuments, targetFolder);

        // Body of create-page try
        {
            var createdUrl = await builder.CreateFromExportAsync(selectedCandidate.FullPath);
            Console.WriteLine("[Page] Created: " + createdUrl);
        }
    }


    static async Task EnsureFolderAsync(IPage page, string name)
    {
        if (await FolderRowExistsAsync(page, name))
        {
            Console.WriteLine($"[Folder] Exists: {name}");
            return;
        }

        Console.WriteLine($"[Folder] Creating: {name}");

        // Prefer automation id for New
        if (!await ClickByAutomationIdAsync(page, "newCommand", 8000))
        {
            // overflow -> then New
            if (!await ClickByAutomationIdAsync(page, "moreCommand", 4000))
                await ClickAnyAsync(page, new[] { "button[aria-label*='Więcej' i]", "button:has-text('Więcej')", "button[aria-label*='More' i]", "button:has-text('More')" });
            if (!await TryClickAsync(page, "div[role='menu'] [role='menuitem'][data-automationid='newCommand']"))
                await ClickAnyAsync(page, new[] { "div[role='menu'] [role='menuitem']:has-text('New')", "div[role='menu'] [role='menuitem']:has-text('Nowy')" });
        }

        await ClickAnyAsync(page, new[] {
                "div[role='menu'] [role='menuitem']:has-text('Folder')",
                "button[role='menuitem']:has-text('Folder')"
            }, 12000);

        var textbox = page.GetByRole(AriaRole.Textbox).First;
        await textbox.FillAsync(name);

        await ClickAnyAsync(page, new[] {
                "button[data-automationid='primaryButton']",
                "button:has-text('Create')",
                "button:has-text('Utwórz')"
            }, 15000);

        await page.WaitForSelectorAsync($"[role='row'] >> text=\"{name}\"", new() { Timeout = 25000 });
    }


    static async Task OpenFolderAsync(IPage page, string name)
    {
        var row = page.Locator($"[role='row'] >> text=\"{name}\"").First;
        await row.ClickAsync();
        await page.WaitForTimeoutAsync(400);
    }


    static string ResolveAttachmentsSource(string inputPath)
    {
        var attachments = Path.Combine(inputPath, "attachments");
        return Directory.Exists(attachments) ? attachments : inputPath;
    }


    static async Task UploadFilesAsync(IPage page, string[] files)
    {
        // Otwórz Upload → Files i przechwyć systemowy FileChooser
        var chooser = await page.RunAndWaitForFileChooserAsync(async () =>
        {
            // Upload (automation-id + overflow fallback)
            if (!await ClickByAutomationIdAsync(page, "uploadCommand", 6000))
            {
                if (!await ClickByAutomationIdAsync(page, "moreCommand", 4000))
                    await ClickAnyAsync(page, new[] { "button[aria-label*='Więcej' i]", "button:has-text('Więcej')", "button[aria-label*='More' i]", "button:has-text('More')" });

                if (!await TryClickAsync(page, "div[role='menu'] [role='menuitem'][data-automationid='uploadCommand']"))
                    await ClickAnyAsync(page, new[] { "div[role='menu'] [role='menuitem']:has-text('Upload')", "div[role='menu'] [role='menuitem']:has-text('Przekaż')", "div[role='menu'] [role='menuitem']:has-text('Prześlij')" });
            }

            // Po otwarciu menu wybierz „Files/Pliki” – to właśnie wywołuje FileChooser
            await ClickAnyAsync(page, new[] {
                    "div[role='menu'] [role='menuitem']:has-text('Files')",
                    "div[role='menu'] [role='menuitem']:has-text('Pliki')"
            }, 12000);
        });

        // Zamiast klikać natywne okno – ustaw pliki programowo
        await chooser.SetFilesAsync(files.Select(p => p.Replace("/", "\\")).ToArray());

        // Poczekaj aż pojawią się wiersze z nazwami
        foreach (var f in files)
        {
            var name = Path.GetFileName(f);
            try
            {
                await page.WaitForSelectorAsync($"[role='row'] >> text=\"{name}\"", new() { Timeout = 30000 });
                Console.WriteLine($"[Upload] ✓ {name}");
            }
            catch
            {
                Console.WriteLine($"[Upload] (?) no row for {name}");
            }
        }
    }


    static async Task ClickAnyAsync(IPage page, IEnumerable<string> selectors, int timeout = 10000)
    {
        Exception? last = null;
        foreach (var sel in selectors)
        {
            try
            {
                var loc = page.Locator(sel).First;
                await loc.WaitForAsync(new() { Timeout = timeout });
                await loc.ClickAsync();
                return;
            }
            catch (Exception ex) { last = ex; }
        }
        throw new TimeoutException("None of the selectors could be clicked. Last: " + last?.Message);
    }


    static async Task<bool> ClickByAutomationIdAsync(IPage page, string automationId, int timeout = 8000)
    {
        try
        {
            var loc = page.Locator($"[data-automationid='{automationId}']").First;
            await loc.WaitForAsync(new() { Timeout = timeout });
            await loc.ClickAsync();
            return true;
        }
        catch { return false; }
    }


    static async Task<bool> TryClickAsync(IPage page, string selector, int timeout = 6000)
    {
        try
        {
            var l = page.Locator(selector).First;
            await l.WaitForAsync(new() { Timeout = timeout });
            await l.ClickAsync();
            return true;
        }
        catch { return false; }
    }


    static async Task<bool> FolderRowExistsAsync(IPage page, string name)
    {
        try
        {
            await page.Locator($"[role='row'] >> text=\"{name}\"").First.WaitForAsync(new() { Timeout = 2000 });
            return true;
        }
        catch { return false; }
    }
}
