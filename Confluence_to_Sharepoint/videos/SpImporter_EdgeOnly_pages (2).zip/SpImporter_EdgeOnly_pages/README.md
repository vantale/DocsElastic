
# SpImporter_EdgeOnly_pages

**Edge-only (.NET 9 + Playwright) + persistent profile**, upload do `Documents/Confluence/<TargetFolderName>` **i** tworzenie **modern page** z eksportu HTML.

## Użycie
```powershell
cd <ścieżka>\SpImporter_EdgeOnly_pages
dotnet restore
dotnet build
dotnet run
```

## Co robi
1. Wymusza Microsoft Edge (`ExecutablePath=msedge.exe`), profil w `%LOCALAPPDATA%\SpImporter_EdgeOnly\Profile`.
2. Tworzy `Documents/Confluence/<TargetFolderName>` (domyślnie `Sample-Page-One`).
3. Uploaduje pliki z `InputPath\attachments` (jeśli brak – z `InputPath`).
4. **ModernPageBuilder**:
   - otwiera `SitePages` → `New → Site page`,
   - tytuł = nazwa katalogu,
   - z HTML wyodrębnia bloki: Tekst / IMG / LINK,
   - IMG → Image web part z linkiem do pliku w Documents,
   - LINK → wstawia tekst z URL-em do pliku,
   - **Publish** i wypisuje URL.

## Główne wywołanie (już w Program.cs)
```csharp
var builder = new ModernPageBuilder(page, cfg.SiteUrl, cfg.RootInDocuments, targetFolder);
var createdUrl = await builder.CreateFromExportAsync(cfg.InputPath);
Console.WriteLine("[Page] Created: " + createdUrl);
```
