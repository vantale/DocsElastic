using Microsoft.Playwright;
using SpImporter_EdgeOnly_pages;

record Config(
    string SiteUrl,
    bool Headless,
    string UserDataDir,
    string EdgePath,
    string InputPath,
    string RootInDocuments,
    string TargetFolderName
);

class Program
{
    static async Task<int> Main(string[] args)
    {
        IBrowserContext? ctx = null;
        IPage? page = null;

        var init = await Initialiser.InitializeAsync();
        using var pw = init.pw; // zachowuje ten sam czas życia co wcześniej
        ctx = init.ctx;
        page = init.page;
        var cfg = init.cfg!;
        var targetFolder = init.targetFolder;
        bool tracingStarted = init.tracingStarted;
        bool tracingStopped = init.tracingStopped;
        bool docsChunkOpen = init.docsChunkOpen;
        bool createChunkOpen = init.createChunkOpen;

        try
        {

            var candidates = HarvestedPagesManager.ListHarvestedPageCandidates(cfg.InputPath);
            var selectedCandidate = candidates.First();

            Console.WriteLine($"SELECTED CANDIDATE FULL PATH: {selectedCandidate.FullPath}");

            await page.GotoAsync(cfg.SiteUrl, new() { WaitUntil = WaitUntilState.DOMContentLoaded });
            Console.WriteLine("[Login] Jeśli to pierwszy raz – zaloguj się w tym oknie Edge. Sesja zapisze się w profilu.");

            // ------------ Tworzenie strony ------------
            await ctx.Tracing.StartChunkAsync(new TracingStartChunkOptions { Title = "create-page" });
            createChunkOpen = true;

            try
            {
                var worker = new Worker();

                foreach(var candidate in candidates)
                {
                    await worker.ExecuteAsync(ctx!, page!, cfg, candidate, targetFolder);
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("[FATAL] " + ex);

                if (createChunkOpen)
                {
                    try
                    {
                        await ctx.Tracing.StopChunkAsync(new() { Path = Path.Combine(Diag.RunDir, "trace-create.zip") });
                    }
                    catch (Exception stopChunkEx)
                    {
                        Console.WriteLine("[TRACE] stop chunk (create) failed: " + stopChunkEx.Message);
                    }
                    createChunkOpen = false;
                }

                if (tracingStarted && !tracingStopped)
                {
                    try
                    {
                        await ctx.Tracing.StopAsync(new() { Path = Path.Combine(Diag.RunDir, "trace.zip") });
                        Console.WriteLine("[TRACE] " + Path.Combine(Diag.RunDir, "trace.zip"));
                        tracingStopped = true;
                    }
                    catch (Exception stopEx)
                    {
                        Console.WriteLine("[TRACE] early stop failed: " + stopEx.Message);
                    }
                }

                throw;
            }
            finally
            {
                if (createChunkOpen)
                {
                    try
                    {
                        await ctx.Tracing.StopChunkAsync(new() { Path = Path.Combine(Diag.RunDir, "trace-create.zip") });
                    }
                    catch (Exception ex2)
                    {
                        Console.WriteLine("[TRACE] stop chunk (create) failed: " + ex2.Message);
                    }
                    createChunkOpen = false;
                }
            }

        }
        finally
        {
            // główny trace – drugi „bezpiecznik”
            if (ctx != null && tracingStarted && !tracingStopped)
            {
                var tracePath = Path.Combine(Diag.RunDir, "trace.zip");
                try
                {
                    await ctx.Tracing.StopAsync(new() { Path = tracePath });
                    Console.WriteLine("[TRACE] " + tracePath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("[TRACE] stop failed: " + ex.Message);
                }
            }
        }
        return 0;
    }
}