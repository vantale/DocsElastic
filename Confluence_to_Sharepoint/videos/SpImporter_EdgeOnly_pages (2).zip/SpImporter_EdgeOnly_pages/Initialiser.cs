﻿using Microsoft.Playwright;
using System.Text.Json;

namespace SpImporter_EdgeOnly_pages;

internal class Initialiser
{
    public static async Task<(IPlaywright pw,
                          IBrowserContext ctx,
                          IPage page,
                          Config cfg,
                          string targetFolder,
                          bool tracingStarted,
                          bool tracingStopped,
                          bool docsChunkOpen,
                          bool createChunkOpen)> InitializeAsync()
    {
        // helpery do bezpiecznego ustawiania opcji nagrywania (refleksja)
        static void TrySetOption(object options, string prop, object? value)
        {
            var p = options.GetType().GetProperty(prop);
            if (p != null && p.CanWrite) p.SetValue(options, value);
        }

        static object? NewVideoSizeFromAssembly(object anchor, int w, int h)
        {
            var asm = anchor.GetType().Assembly;
            var t = asm.GetType("Microsoft.Playwright.VideoSize");
            if (t == null) return null;
            var vs = Activator.CreateInstance(t);
            t.GetProperty("Width")?.SetValue(vs, w);
            t.GetProperty("Height")?.SetValue(vs, h);
            return vs;
        }

        bool tracingStarted = false;
        bool tracingStopped = false;
        bool docsChunkOpen = false;
        bool createChunkOpen = false;

        var cfg = LoadConfig();
        var userDataDir = ExpandEnv(cfg.UserDataDir);
        Directory.CreateDirectory(userDataDir);

        var targetFolder = string.IsNullOrWhiteSpace(cfg.TargetFolderName)
            ? new DirectoryInfo(cfg.InputPath).Name
            : cfg.TargetFolderName.Trim();

        var edgeExe = ResolveEdgePath(cfg.EdgePath);
        Console.WriteLine($"[Edge] {edgeExe}");
        Console.WriteLine($"[Profile] {userDataDir}");

        // === ARTIFACTS DIR per run (wcześniej, bo użyjemy w nagrywaniu) ===
        var runId = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        var artifactsDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SpImporter_EdgeOnly", "Artifacts", runId);
        Directory.CreateDirectory(artifactsDir);
        Diag.RunDir = artifactsDir;
        Console.WriteLine("[ART] " + artifactsDir);

        var pw = await Playwright.CreateAsync(); // disposal w Main (using var pw = init.pw)

        // Opcje persistent context – dopinamy nagrywanie wideo/HAR (jeśli wspierane)
        var ctxOptions = new BrowserTypeLaunchPersistentContextOptions
        {
            ExecutablePath = edgeExe,
            Headless = cfg.Headless,
            ViewportSize = ViewportSize.NoViewport
        };
        TrySetOption(ctxOptions, "RecordVideoDir", artifactsDir);
        var vs = NewVideoSizeFromAssembly(ctxOptions, 1280, 800);
        if (vs != null) TrySetOption(ctxOptions, "RecordVideoSize", vs);
        TrySetOption(ctxOptions, "RecordHarPath", Path.Combine(artifactsDir, "network.har"));

        var ctx = await pw.Chromium.LaunchPersistentContextAsync(userDataDir, ctxOptions);
        var page = ctx.Pages.FirstOrDefault() ?? await ctx.NewPageAsync();

        var ua = await page.EvaluateAsync<string>("() => navigator.userAgent");
        Console.WriteLine("[UA] " + ua);

        // === TRACING (screenshots + DOM snapshots + sources) ===
        await ctx.Tracing.StartAsync(new()
        {
            Screenshots = true,
            Snapshots = true,
            Sources = true
        });
        tracingStarted = true;

        // === Dodatkowe logi przeglądarki / sieci ===
        page.Console += (_, msg) => Console.WriteLine("[BROWSER] " + msg.Text);
        page.RequestFailed += (_, r) => Console.WriteLine($"[REQ-FAIL] {r.Method} {r.Url} -> {r.Failure}");
        page.Response += (_, resp) =>
        {
            if (resp.Status >= 400)
                Console.WriteLine($"[HTTP] {resp.Status} {resp.Url}");
        };

        return (pw, ctx, page, cfg, targetFolder, tracingStarted, tracingStopped, docsChunkOpen, createChunkOpen);
    }
    // ─────────────────────────────────────────────────────────────────────────────

    static Config LoadConfig()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        if (!File.Exists(path))
            throw new InvalidOperationException($"Missing appsettings.json at {path}");
        using var s = File.OpenRead(path);
        var cfg = JsonSerializer.Deserialize<Config>(s, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        if (cfg is null) throw new InvalidOperationException("Invalid config.");
        if (string.IsNullOrWhiteSpace(cfg.SiteUrl)) throw new InvalidOperationException("SiteUrl is required.");
        if (string.IsNullOrWhiteSpace(cfg.InputPath)) throw new InvalidOperationException("InputPath is required.");
        return cfg!;
    }

    static string ExpandEnv(string p) =>
        Environment.ExpandEnvironmentVariables(p.Replace("/", Path.DirectorySeparatorChar.ToString()));

    static string ResolveEdgePath(string overridePath)
    {
        if (!string.IsNullOrWhiteSpace(overridePath) && File.Exists(overridePath)) return overridePath;
        var env = Environment.GetEnvironmentVariable("MSEDGE_PATH");
        if (!string.IsNullOrWhiteSpace(env) && File.Exists(env)) return env;
        var candidates = new[]
        {
        @"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        @"C:\Program Files\Microsoft\Edge Beta\Application\msedge.exe",
        @"C:\Program Files (x86)\Microsoft\Edge Beta\Application\msedge.exe",
        @"C:\Program Files\Microsoft\Edge Dev\Application\msedge.exe",
        @"C:\Program Files (x86)\Microsoft\Edge Dev\Application\msedge.exe",
        @"C:\Program Files\Microsoft\Edge SxS\Application\msedge.exe",
        @"C:\Program Files (x86)\Microsoft\Edge SxS\Application\msedge.exe"
    };
        foreach (var c in candidates) if (File.Exists(c)) return c;
        throw new InvalidOperationException("Nie znaleziono msedge.exe. Ustaw EdgePath w appsettings.json lub MSEDGE_PATH.");
    }
}
