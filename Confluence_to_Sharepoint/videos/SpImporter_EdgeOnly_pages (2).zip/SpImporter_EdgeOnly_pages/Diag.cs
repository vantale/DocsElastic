﻿public static class Diag
{
    // Katalog dla artefaktów (trace, zrzuty)
    public static string RunDir = "";
}
