using Microsoft.Playwright;
using System.Net;
using System.Text.RegularExpressions;

public class ModernPageBuilder
{
    private readonly IPage _page;
    private readonly string _siteUrl;
    private readonly string _docsRoot;
    private readonly string _folderName;

    public ModernPageBuilder(IPage page, string siteUrl, string documentsRoot, string folderName)
    {
        _page = page;
        _siteUrl = siteUrl.TrimEnd('/');
        _docsRoot = documentsRoot;
        _folderName = folderName;
    }

    // === URL helpers ===
    private static string JoinUrl(string baseUrl, params string[] segments)
    {
        var parts = segments
            .Where(s => !string.IsNullOrWhiteSpace(s))
            .Select(s => Uri.EscapeDataString(s.Replace("\\", "/").Trim('/')));
        return $"{baseUrl.TrimEnd('/')}/{string.Join("/", parts)}";
    }

    private string BuildServerFileUrl(string fileName)
        => JoinUrl(_siteUrl, "Shared Documents", _docsRoot, _folderName, fileName);

    private string BuildServerFolderUrl()
        => JoinUrl(_siteUrl, "Shared Documents", _docsRoot, _folderName);

    /// <summary>
    /// Tworzy modern page z HTML w inputDir: obrazy wstawia jako Image web part (z Documents),
    /// zwykłe linki dodaje jako tekst z URL-em. Zwraca URL opublikowanej strony.
    /// </summary>
    public async Task<string> CreateFromExportAsync(string inputDir)
    {
        try
        {
            var htmlPath = ResolveHtmlPath(inputDir);
            Console.WriteLine("[Page] Source html: " + htmlPath);
            var html = await File.ReadAllTextAsync(htmlPath);
            var title = new DirectoryInfo(inputDir).Name;

            await GoToSitePagesAsync();
            await CreateBlankPageAsync(title);

            var blocks = SplitIntoBlocks(html);

            foreach (var b in blocks)
            {
                if (b.Kind == BlockKind.Text && !string.IsNullOrWhiteSpace(b.Text))
                {
                    await EnsureTextWebPartAsync();
                    await InsertTextAsync(b.Text);
                }
                else if (b.Kind == BlockKind.Image)
                {
                    // Realna nazwa obrazka (czyść query typu 960x480?text=…)
                    var fileName = ResolveImageFileName(inputDir, b.FileName);
                    if (fileName == null) continue;
                    var serverUrl = BuildServerFileUrl(fileName);
                    await InsertImageWebPartAsync(serverUrl);
                }
                else if (b.Kind == BlockKind.Link && !string.IsNullOrWhiteSpace(b.FileName))
                {
                    var fileName = b.FileName.Trim();
                    var serverUrl = BuildServerFileUrl(fileName);
                    await EnsureTextWebPartAsync();
                    await InsertTextAsync($"{fileName}: {serverUrl}");
                }
            }

            // Załączniki (linki do nie-obrazów)
            await InsertAttachmentsSectionAsync(inputDir);

            // Dla pewności ustaw tytuł tuż przed publikacją
            await SetTitleAsync(_page, title);

            var published = await PublishAsync();
            return published;
        }
        catch (Exception)
        {
            try
            {
                var path = Path.Combine(Diag.RunDir, "99_error.png");
                await _page.ScreenshotAsync(new() { Path = path, FullPage = true });
                Console.WriteLine("[SHOT] " + path);
            }
            catch { /* best effort */ }
            throw;
        }
    }

    // === attachments helpers ===
    private static readonly HashSet<string> ImageExt = new(StringComparer.OrdinalIgnoreCase)
    { ".png",".jpg",".jpeg",".gif",".bmp",".webp",".svg",".tif",".tiff",".ico" };

    private static string? ResolveImageFileName(string inputDir, string? candidateFromHtml)
    {
        var attachmentsDir = Path.Combine(inputDir, "attachments");
        var cleaned = CleanFileName(candidateFromHtml);
        var looksLikeImage = !string.IsNullOrWhiteSpace(cleaned) && ImageExt.Contains(Path.GetExtension(cleaned));

        if (looksLikeImage)
        {
            var full = Path.Combine(attachmentsDir, cleaned!);
            if (File.Exists(full)) return cleaned;
        }

        // fallback: pierwszy prawdziwy obraz w attachments
        if (Directory.Exists(attachmentsDir))
        {
            var first = Directory.EnumerateFiles(attachmentsDir)
                .FirstOrDefault(p => ImageExt.Contains(Path.GetExtension(p)));
            if (first != null) return Path.GetFileName(first);
        }

        return null;
    }

    private static string? CleanFileName(string? urlOrName)
    {
        if (string.IsNullOrWhiteSpace(urlOrName)) return null;
        var noFrag = urlOrName.Split('#')[0];
        var noQuery = noFrag.Split('?')[0];
        return Path.GetFileName(noQuery);
    }

    private static string ResolveHtmlPath(string dir)
    {
        var candidates = new[] { "index.html", "article.html", "fullpage.html", "page.html" };
        foreach (var c in candidates)
        {
            var p = Path.Combine(dir, c);
            if (File.Exists(p)) return p;
        }
        throw new FileNotFoundException("No HTML file found (index/article/fullpage/page) in " + dir);
    }

    // --- Prosty parser HTML -> bloki ---
    private enum BlockKind { Text, Image, Link }
    private record Block(BlockKind Kind, string Text = "", string FileName = "");

    private static List<Block> SplitIntoBlocks(string html)
    {
        // <a href="..."> -> [[LINK:file]]
        var aRx = new Regex("<a[^>]+href=[\"'](?<href>[^\"']+)[\"'][^>]*>(?<text>.*?)</a>",
            RegexOptions.IgnoreCase | RegexOptions.Singleline);
        html = aRx.Replace(html, m =>
        {
            var href = m.Groups["href"].Value;
            var file = CleanFileName(href);
            if (string.IsNullOrEmpty(file)) return m.Value;
            return $" [[LINK:{file}]] ";
        });

        // <img src="..."> -> [[IMG:file]]
        var imgRx = new Regex("<img[^>]+src=[\"'](?<src>[^\"']+)[\"'][^>]*>", RegexOptions.IgnoreCase);
        html = imgRx.Replace(html, m =>
        {
            var src = m.Groups["src"].Value;
            var file = CleanFileName(src);
            if (string.IsNullOrEmpty(file)) return "";
            return $" [[IMG:{file}]] ";
        });

        // usuń tagi, dekoduj encje
        var noTags = Regex.Replace(html, "<[^>]+>", " ");
        noTags = WebUtility.HtmlDecode(noTags);
        noTags = Regex.Replace(noTags, @"\s+", " ").Trim();

        // poskładaj w kolejności
        var blocks = new List<Block>();
        var tokenRx = new Regex(@"\[\[(IMG|LINK):([^\]]+)\]\]");
        int last = 0;
        foreach (Match m in tokenRx.Matches(noTags))
        {
            if (m.Index > last)
            {
                var text = noTags.Substring(last, m.Index - last).Trim();
                if (!string.IsNullOrWhiteSpace(text))
                    blocks.Add(new Block(BlockKind.Text, Text: text));
            }
            var kind = m.Groups[1].Value;
            var file = m.Groups[2].Value;
            if (kind == "IMG")
                blocks.Add(new Block(BlockKind.Image, FileName: file));
            else
                blocks.Add(new Block(BlockKind.Link, FileName: file));
            last = m.Index + m.Length;
        }
        if (last < noTags.Length)
        {
            var tail = noTags.Substring(last).Trim();
            if (!string.IsNullOrWhiteSpace(tail))
                blocks.Add(new Block(BlockKind.Text, Text: tail));
        }
        return blocks;
    }

    // --- UI kroki ---

    private async Task GoToSitePagesAsync()
    {
        var url = $"{_siteUrl}/SitePages/Forms/AllPages.aspx";
        await _page.GotoAsync(url, new() { WaitUntil = WaitUntilState.DOMContentLoaded, Timeout = 60000 });

        var ok = await ExistsAsync(_page, "[data-automationid='newCommand'], [data-automationid='CommandBar']", 8000);
        if (!ok)
        {
            await _page.GotoAsync($"{_siteUrl}/_layouts/15/viewlsts.aspx", new() { WaitUntil = WaitUntilState.DOMContentLoaded, Timeout = 60000 });

            await ClickAnyAsync(_page, new[]
            {
                "a[href*='SitePages/Forms/AllPages.aspx']",
                "a[title*='Site Pages' i]",
                "a:has-text('Site Pages')",
                "a:has-text('Strony witryny')"
            }, 15000);

            await _page.Locator("[data-automationid='newCommand'], [data-automationid='CommandBar']").First
                       .WaitForAsync(new() { Timeout = 20000 });
        }

        Console.WriteLine("[Page] SitePages opened.");

        await _page.ScreenshotAsync(new()
        {
            Path = Path.Combine(Diag.RunDir, "10_sitepages_opened.png"),
            FullPage = true
        });
    }

    private async Task CreateBlankPageAsync(string title)
    {
        // New → Site page
        if (!await ClickByAutomationIdAsync(_page, "newCommand", 8000))
        {
            if (!await ClickByAutomationIdAsync(_page, "moreCommand", 4000))
                await ClickAnyAsync(_page, new[] { "button[aria-label*='Więcej' i]", "button:has-text('Więcej')", "button[aria-label*='More' i]", "button:has-text('More')" });
        }

        var clicked = await TryClickAsync(_page, "div[role='menu'] [role='menuitem'][data-automationid='sitePage']")
                    || await TryClickAsync(_page, "div[role='menu'] [role='menuitem']:has-text('Site page')")
                    || await TryClickAsync(_page, "div[role='menu'] [role='menuitem']:has-text('Strona witryny')")
                    || await TryClickAsync(_page, "div[role='menu'] [role='menuitem']:has-text('Page')");
        if (!clicked) throw new TimeoutException("Cannot find 'Site page' menu item.");

        await _page.WaitForLoadStateAsync(LoadState.NetworkIdle);
        await _page.Locator("[data-automation-id='pageTitleInput'], textarea#title_text").First
                   .WaitForAsync(new() { Timeout = 30000 });

        await _page.AddStyleTagAsync(new() { Content = "[data-drag-handle='WebpartInsideHandle']{pointer-events:none!important;}" });

        await SetTitleAsync(_page, title);

        await _page.ScreenshotAsync(new()
        {
            Path = Path.Combine(Diag.RunDir, "20_after_title.png"),
            FullPage = true
        });

        Console.WriteLine("[Page] Title set: " + title);
    }

    private async Task InsertTextAsync(string text)
    {
        var editor = _page.Locator("[data-automationid='textBox'], div[contenteditable='true']").First;
        await editor.ClickAsync();
        await _page.Keyboard.TypeAsync(text + "\n\n");
    }

    private async Task InsertImageWebPartAsync(string imageUrl)
    {
        // Otwórz Toolbox
        await OpenToolboxAsync();

        // 1) Spróbuj kliknąć kafelek "Image" (różne warianty językowe)
        var clicked =
            await TryClickByRoleAsync(AriaRole.Button, "Image") ||
            await TryClickByRoleAsync(AriaRole.Menuitem, "Image") ||
            await TryClickByRoleAsync(AriaRole.Button, "Obraz") ||
            await TryClickByRoleAsync(AriaRole.Menuitem, "Obraz") ||
            await TryClickAsync(_page, "button:has-text('Image')") ||
            await TryClickAsync(_page, "button:has-text('Obraz')") ||
            await TryClickAsync(_page, "[role='menuitem']:has-text('Image')") ||
            await TryClickAsync(_page, "[role='menuitem']:has-text('Obraz')") ||
            await TryClickAsync(_page, "[data-automationid='Image']");

        // 2) Jeśli nie ma kafelka w „Frequently used”, wyszukaj
        if (!clicked)
        {
            var search = _page.Locator("input[placeholder*='Search' i], input[aria-label*='Search' i]").First;
            try
            {
                await search.WaitForAsync(new() { Timeout = 6000 });
                await search.FillAsync("Image");
                await _page.WaitForTimeoutAsync(300);
            }
            catch { /* brak wyszukiwarki – zdarza się */ }

            clicked =
                await TryClickByRoleAsync(AriaRole.Button, "Image") ||
                await TryClickByRoleAsync(AriaRole.Menuitem, "Image") ||
                await TryClickAsync(_page, "button:has-text('Image')") ||
                await TryClickAsync(_page, "[role='menuitem']:has-text('Image')");
        }

        if (!clicked)
            throw new TimeoutException("Cannot add Image web part.");

        // 4) Zakładka „From a link”
        var fromLinkTab = _page.Locator("[data-automation-id='filePickerFromALinkTab']").First;
        await fromLinkTab.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = 10000 });
        await fromLinkTab.ScrollIntoViewIfNeededAsync();
        await fromLinkTab.ClickAsync();

        // 5) Wklej URL i Insert
        var urlInput = _page.Locator("[data-automation-id='filePickerLinkTextField']").First;
        await urlInput.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = 10000 });
        await urlInput.FillAsync(imageUrl);
        await urlInput.PressAsync("Tab");

        // „Insert” w obrębie aktywnej zakładki
        var scope = _page.Locator(
          "[data-automation-id='sp-filepicker'] " +
          "[data-automation-id='selectedTab'] " +
          "[data-automation-id='filePickerFromALinkContainer']"
        );

        var insertButton = scope.Locator(
          "button[data-automation-id='OKButton']" +
          ":visible:not([disabled]):not([aria-disabled='true']):not(.is-disabled)"
        );

        await insertButton.ClickAsync();

        // Dialog „Copy image to this page?” – kliknij „Copy” tylko jeśli jest
        try
        {
            var dlg = _page.GetByRole(AriaRole.Alertdialog, new() { NameRegex = new("(Copy image to this page\\??|Skopiuj obraz.*)", RegexOptions.IgnoreCase) });
            var copyBtn = dlg.Locator("button[data-automation-id='yesButton']:not([disabled]):not([aria-disabled='true']):not(.is-disabled)");
            await copyBtn.ClickAsync(new() { Timeout = 2000 });
        }
        catch { /* brak popupu = OK */ }

        await _page.WaitForTimeoutAsync(300);
    }

    private async Task<string> PublishAsync()
    {
        if (!await ClickByAutomationIdAsync(_page, "publish", 6000))
        {
            await ClickAnyAsync(_page, new[] { "button:has-text('Publish')", "button:has-text('Opublikuj')" }, 8000);
        }
        await _page.WaitForURLAsync("**/SitePages/**", new() { Timeout = 20000 });
        var url = _page.Url;
        Console.WriteLine("[Page] Published: " + url);
        return url;
    }

    // Utils
    private static async Task<bool> TryClickAsync(IPage page, string selector, int timeout = 6000)
    {
        try { var l = page.Locator(selector).First; await l.WaitForAsync(new() { Timeout = timeout }); await l.ClickAsync(); return true; }
        catch { return false; }
    }
    private static async Task<bool> ClickByAutomationIdAsync(IPage page, string automationId, int timeout = 8000)
    {
        try { var loc = page.Locator($"[data-automationid='{automationId}']").First; await loc.WaitForAsync(new() { Timeout = timeout }); await loc.ClickAsync(); return true; }
        catch { return false; }
    }
    private static async Task<bool> ExistsAsync(IPage page, string selector, int timeout = 1000)
    {
        try { await page.Locator(selector).First.WaitForAsync(new() { Timeout = timeout }); return true; }
        catch { return false; }
    }

    private static async Task ClickAnyAsync(IPage page, IEnumerable<string> selectors, int timeout = 10000)
    {
        Exception? last = null;
        foreach (var sel in selectors)
        {
            try
            {
                var loc = page.Locator(sel).First;
                await loc.WaitForAsync(new() { Timeout = timeout });
                await loc.ClickAsync();
                return;
            }
            catch (Exception ex) { last = ex; }
        }
        throw new TimeoutException("None of the selectors could be clicked. Last: " + last?.Message);
    }

    private async Task EnsureTextWebPartAsync()
    {
        if (await ExistsAsync(_page, "[data-automationid='textBox'], div[contenteditable='true']"))
            return;

        try { await _page.ClickAsync("div[role='main']"); } catch { }
        await _page.Keyboard.PressAsync("Enter");
        if (await ExistsAsync(_page, "div[contenteditable='true']", 1200))
            return;

        await OpenToolboxAsync();
        var ok = await TryClickAsync(_page, "button:has-text('Text')")
              || await TryClickAsync(_page, "[role='menuitem']:has-text('Text')")
              || await TryClickAsync(_page, "[data-automationid='Text']")
              || await TryClickAsync(_page, "div[role='menu'] [role='menuitem']:has-text('Text')")
              || await TryClickAsync(_page, "button:has-text('Tekst')");
        if (!ok) throw new TimeoutException("Cannot add Text web part.");

        await _page.Locator("[data-automationid='textBox'], div[contenteditable='true']").First
                   .WaitForAsync(new() { Timeout = 10000 });
    }

    private async Task OpenToolboxAsync()
    {
        await _page.AddStyleTagAsync(new() { Content = "[data-drag-handle]{pointer-events:none!important;}" });

        try { await _page.ClickAsync("div[role='main']", new() { Position = new() { X = 200, Y = 200 } }); } catch { }

        var clicked = await TryClickAsync(_page, "button[data-automationid='addWebPart']")
                   || await TryClickAsync(_page, "button[aria-label*='Add a new web part' i]")
                   || await TryClickAsync(_page, "button[aria-label*='Add web part' i]")
                   || await TryClickAsync(_page, "button[aria-label*='Dodaj' i]");

        if (!clicked)
        {
            await _page.Keyboard.PressAsync("Shift+Alt+N");
            await _page.WaitForTimeoutAsync(150);
        }

        if (!clicked)
        {
            clicked = await _page.EvaluateAsync<bool>(@"() => {
              const sels = [
                'button[data-automationid=""addWebPart""]',
                'button[aria-label*=""Add a new web part"" i]',
                'button[aria-label*=""Add web part"" i]',
                'button[aria-label*=""Dodaj"" i]'
              ];
              for (const s of sels) { const b = document.querySelector(s); if (b) { b.click(); return true; } }
              return false;
            }");
        }

        await _page.Locator(
            "button:has-text('Text'), button:has-text('Image'), input[placeholder*='Search' i]"
        ).First.WaitForAsync(new() { Timeout = 20000 });
    }

    private static async Task SetTitleAsync(IPage page, string title)
    {
        // pole tytułu (input/textarea)
        var input = page.Locator("[data-automation-id='pageTitleInput'], textarea#title_text").First;
        try
        {
            await input.WaitForAsync(new() { Timeout = 8000 });
            await input.FocusAsync();
            await page.Keyboard.PressAsync("Control+A");
            await page.Keyboard.TypeAsync(title);
            await page.Keyboard.PressAsync("Tab");
        }
        catch { }

        // heading contenteditable
        try
        {
            var heading = page.Locator(
                "div[aria-label*='Title' i] [contenteditable='true'], " +
                "[role='textbox'][aria-label*='title' i], " +
                "h1[contenteditable='true'], " +
                "div[data-automation-id='pageHeader'] [contenteditable='true']"
            ).First;

            await heading.WaitForAsync(new() { Timeout = 8000 });
            await heading.FocusAsync();
            await page.Keyboard.PressAsync("Control+A");
            await page.Keyboard.TypeAsync(title);
            await page.Keyboard.PressAsync("Tab");
        }
        catch { }

        // programowe „input/change”
        await page.EvaluateAsync(@"(t) => {
            const fire = el => {
                el.dispatchEvent(new InputEvent('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
                el.blur && el.blur();
            };
            const a = document.querySelector('[data-automation-id=""pageTitleInput""], #title_text');
            if (a) { a.value = t; fire(a); }
            const b = document.querySelector('div[aria-label*=""Title"" i] [contenteditable=""true""], [role=""textbox""][aria-label*=""title"" i], h1[contenteditable=""true""], div[data-automation-id=""pageHeader""] [contenteditable=""true""]');
            if (b) { b.textContent = t; fire(b); }
        }", title);

        // miękka asercja – czy tytuł jest widoczny
        try
        {
            await Assertions.Expect(
                page.Locator($"h1:has-text('{Regex.Escape(title)}'), [data-automation-id='pageTitle']:has-text('{Regex.Escape(title)}')")
                    .First
            ).ToBeVisibleAsync(new() { Timeout = 2000 });
        }
        catch { /* nie blokuj publikacji */ }

        try { await page.ClickAsync("div[role='main']"); } catch { }
        await page.WaitForTimeoutAsync(120);
    }

    // --- Dodatkowe pomoćnicze ---
    private async Task<bool> TryClickByRoleAsync(AriaRole role, string name, int timeout = 6000)
    {
        try
        {
            var el = _page.GetByRole(role, new() { Name = name }).First;
            await el.WaitForAsync(new() { Timeout = timeout });
            await el.ClickAsync();
            return true;
        }
        catch { return false; }
    }

    private static async Task<bool> TryClickIfVisible(ILocator scope, string selector)
    {
        var el = scope.Locator(selector).First;
        if (await el.IsVisibleAsync())
        {
            await el.ScrollIntoViewIfNeededAsync();
            await el.ClickAsync();
            return true;
        }
        return false;
    }

    private static readonly HashSet<string> LinkableExt = new(StringComparer.OrdinalIgnoreCase)
    {
        ".txt",".pdf",".doc",".docx",".xls",".xlsx",".ppt",".pptx",".zip",".rar",".7z",".csv",".json",".xml"
    };

    private async Task InsertAttachmentsSectionAsync(string inputDir)
    {
        var dir = Path.Combine(inputDir, "attachments");
        if (!Directory.Exists(dir)) return;

        var files = Directory.EnumerateFiles(dir)
            .Where(p =>
            {
                var ext = Path.GetExtension(p);
                if (ImageExt.Contains(ext)) return false; // obrazy już wstawiamy jako Image
                return LinkableExt.Contains(ext) || !string.IsNullOrEmpty(ext);
            })
            .OrderBy(Path.GetFileName)
            .ToList();

        if (files.Count == 0) return;

        await EnsureTextWebPartAsync();
        await InsertTextAsync("Attachments:\n");

        foreach (var f in files)
        {
            var name = Path.GetFileName(f);
            var url = BuildServerFileUrl(name);
            await InsertHyperlinkAsync(name, url);
            await _page.Keyboard.PressAsync("Enter");
        }
    }

    /// <summary>Wstawia link w aktualnym edytorze RTE: widoczny napis + URL (Ctrl+K).</summary>
    private async Task InsertHyperlinkAsync(string textToDisplay, string url)
    {
        var rte = _page.Locator("[data-automationid='textBox'], div[contenteditable='true']").First;
        await rte.WaitForAsync(new() { Timeout = 10000 });
        await rte.ClickAsync();

        await _page.Keyboard.TypeAsync(textToDisplay);
        await _page.Keyboard.PressAsync("Shift+Home");

        await _page.Keyboard.PressAsync("Control+K");

        var addr = _page.Locator(
            "input[type='url']," +
            "input[aria-label*='address' i], input[placeholder*='address' i]," +
            "input[aria-label*='adres' i],   input[placeholder*='adres' i]," +
            "input[aria-label*='link' i],    input[placeholder*='link' i]"
        ).First;

        await addr.WaitForAsync(new() { Timeout = 8000 });
        await addr.FillAsync(url);
        await addr.PressAsync("Enter");

        await _page.WaitForTimeoutAsync(150);
    }
}
