# Angular 15 + Matomo (SAFE)

To wydanie ogranicza ryzyko zawieszenia aplikacji:
- `enableLinkTracking()` wywoływane jest **tylko raz** przy inicjalizacji,
- wszystkie operacje trackera są uruchamiane **poza strefą Angulara** (`NgZone.runOutsideAngular`),
- pierwszy `pageview` wysyłany jest w `ngAfterViewInit`, aby uniknąć pętli podczas startu,
- dodany `environment.matomo.enabled` jako szybki kill‑switch.

## Szybki start
1. Ustaw `matomo.url` i `matomo.siteId` w `environment*.ts`.
2. Usuń wszelkie wcześniejsze wstawki Matomo z `index.html` (nie duplikuj integracji).
3. Uruchom aplikację i w DevTools → Network sprawdź żądania do `matomo.php`.

## Debug
- Jeśli strona wciąż się wiesza, ustaw `enabled: false` — aplikacja powinna działać bez trackingu.
- Sprawdź, czy `https://<MATOMO>/matomo.js` i `https://<MATOMO>/matomo.php` są dostępne (status 200).
- Wyłącz rozszerzenia AdBlock/Tracking Protection na czas testu lub użyj okna Incognito.
