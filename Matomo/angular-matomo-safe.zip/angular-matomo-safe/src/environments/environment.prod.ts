export const environment = {
  production: true,
  matomo: {
    enabled: true,
    url: 'https://twoj-matomo.example.com/',
    siteId: '1',
  },
};
