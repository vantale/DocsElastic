export const environment = {
  production: false,
  matomo: {
    enabled: true, // szybki kill-switch
    url: 'https://twoj-matomo.example.com/',
    siteId: '1',
  },
};
