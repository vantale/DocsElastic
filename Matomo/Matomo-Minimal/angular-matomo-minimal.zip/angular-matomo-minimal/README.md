# Angular 15 + Matomo (minimal)

Ten pakiet zawiera minimalną integrację Matomo dla SPA w Angularze 15:
- **MatomoService** do inicjalizacji i wysyłania pageview/eventów,
- Hook w `AppComponent` do śledzenia zmian trasy,
- Konfigurację w `environment.ts` / `environment.prod.ts`.

## Konfiguracja
1. Ustaw własne wartości w `src/environments/environment*.ts`:
   - `matomo.url` — adres instancji Matomo (np. `https://matomo.example.com/`).
   - `matomo.siteId` — ID witryny z Matomo.

2. Upewnij się, że Matomo jest dostępne pod:
   - `https://<MATOMO_URL>/matomo.js`
   - `https://<MATOMO_URL>/matomo.php`

3. Zbuduj i uruchom aplikację. W DevTools → Network filtruj `matomo.php`,
   w panelu Matomo sprawdź **Visitors → Real-time**/**Visits log**.

## Notatki
- Serwis dynamicznie wstrzykuje `matomo.js` i wysyła pierwszy `trackPageView()`.
- Każda zmiana trasy w Angular Router skutkuje kolejnym `trackPageView()`.
- W kolejnej iteracji można dodać tryb „privacy-first” (cookieless, sanitizacja URL, itd.).
