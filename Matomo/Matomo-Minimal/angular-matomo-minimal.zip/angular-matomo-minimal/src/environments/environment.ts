export const environment = {
  production: false,
  matomo: {
    url: 'https://twoj-matomo.example.com/',
    siteId: '1',
  },
};
