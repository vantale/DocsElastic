export const environment = {
  production: true,
  matomo: {
    url: 'https://twoj-matomo.example.com/',
    siteId: '1',
  },
};
