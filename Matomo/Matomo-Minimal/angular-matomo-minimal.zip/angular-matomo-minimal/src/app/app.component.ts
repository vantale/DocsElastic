import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { MatomoService } from './services/matomo.service';

@Component({
  selector: 'app-root',
  template: '<router-outlet></router-outlet>',
})
export class AppComponent {
  private lastUrl = window.location.pathname + window.location.search;
  private skipFirst = true; // unikamy zdublowania pierwszego pageview (bo serwis już wysłał)

  constructor(router: Router, private readonly matomo: MatomoService) {
    // 1) Inicjalizacja trackera
    this.matomo.init();

    // 2) Track na każdą zmianę trasy
    router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe((e: NavigationEnd) => {
        if (this.skipFirst) { this.skipFirst = false; return; }

        const current = window.location.pathname + window.location.search;
        const title = document.title;

        this.matomo.trackPageView(current, title, this.lastUrl);
        this.lastUrl = current;
      });
  }
}
