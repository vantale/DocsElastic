import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { environment } from '../../environments/environment';

declare global {
  interface Window { _paq?: any[]; }
}

@Injectable({ providedIn: 'root' })
export class MatomoService {
  private initialized = false;

  private get baseUrl(): string {
    const u = environment.matomo.url?.trim() || '';
    return u.endsWith('/') ? u : u + '/';
  }

  constructor(
    @Inject(DOCUMENT) private readonly document: Document,
    @Inject(PLATFORM_ID) private readonly platformId: Object,
  ) {}

  /** Jednorazowa inicjalizacja trackera + pierwszy pageview */
  init(): void {
    if (this.initialized || !isPlatformBrowser(this.platformId)) return;

    const w = window as Window;
    w._paq = w._paq || [];

    // Minimalny zestaw: pierwszy pageview + outlink/download tracking
    w._paq.push(['trackPageView']);
    w._paq.push(['enableLinkTracking']);

    // Ustawienia trackera
    w._paq.push(['setTrackerUrl', this.baseUrl + 'matomo.php']);
    w._paq.push(['setSiteId', environment.matomo.siteId]);

    // Wstrzyknięcie skryptu matomo.js (jeśli jeszcze nie ma)
    const existing = this.document.querySelector<HTMLScriptElement>(
      `script[src="${this.baseUrl}matomo.js"]`
    );
    if (!existing) {
      const g = this.document.createElement('script');
      g.async = true;
      g.src = this.baseUrl + 'matomo.js';
      const s = this.document.getElementsByTagName('script')[0];
      s?.parentNode?.insertBefore(g, s);
    }

    // Debug pomocniczy
    w._paq.push([function () {
      // @ts-ignore - this wskazuje na tracker Matomo
      // eslint-disable-next-line no-console
      console.debug('[Matomo] tracker ready | siteId=', this.getSiteId?.(), 'url=', this.getTrackerUrl?.());
    }]);

    this.initialized = true;
  }

  /** Pageview dla SPA; podaj aktualny URL (bez domeny), tytuł i opcjonalnie referrer */
  trackPageView(url?: string, title?: string, referrer?: string): void {
    if (!isPlatformBrowser(this.platformId)) return;
    const w = window as Window;
    w._paq = w._paq || [];

    if (referrer) w._paq.push(['setReferrerUrl', referrer]);
    if (url)      w._paq.push(['setCustomUrl', url]);
    if (title)    w._paq.push(['setDocumentTitle', title]);

    w._paq.push(['trackPageView']);
    w._paq.push(['enableLinkTracking']); // utrzymuj włączone po każdej zmianie trasy
  }

  /** Przykład eventów (opcjonalne) */
  trackEvent(category: string, action: string, name?: string, value?: number): void {
    if (!isPlatformBrowser(this.platformId)) return;
    const w = window as Window;
    w._paq = w._paq || [];
    w._paq.push(['trackEvent', category, action, name, value]);
  }
}
